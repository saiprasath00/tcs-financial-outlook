# Dashboard Build Specification

## Canvas and model

- Four 1280 × 720 pages in PBIR enhanced report format.
- Currency: ₹ crore. Percentages: one decimal unless greater precision is needed.
- Seven tables: `Historical`, `Scenario Assumptions`, `Forecast Scenario`, `Timeline`, `Forecast Driver`, `Scenario Selector`, and `Forecast Year`.
- `Scenario Selector` and `Forecast Year` are disconnected controls consumed through `SELECTEDVALUE`.
- Default context: **Base Case / FY2028**. FY2026 remains actual and is not a forecast-year option.

## Pages

| Page | Required content |
|---|---|
| Executive Overview | Scenario/year controls; Revenue, Calculated EBITDA Proxy, Adjusted PAT, and Organic FCF cards; planning context; actual-to-scenario revenue timeline; selected outputs and growth. |
| Trend & Profitability | Historical revenue and margins; profit/FCF comparison; auditable historical values. |
| Scenario & Drivers | Controls; selected Revenue and EBITDA Proxy; isolated all-scenario comparison; implied-driver table; scenario caveat. |
| Financial Detail | Controls plus detail-only FY2025 selector; four forecast cards; detail chart/table; selected forecast outputs. |

## Interaction contract

- Scenario and Forecast Year filter selected forecast visuals.
- The all-scenario comparison remains isolated so Bull/Base/Bear stay visible together.
- The historical selector affects only the detail metric chart/table.
- Evidence charts/tables do not cross-filter controls or headline cards.
- Scenario and Forecast Year slicers are configured for cross-page sync; visible behavior remains in the Desktop checklist.

## Accessibility and release rules

- Tab order: header, controls, KPIs, charts, tables, notes.
- Every visual has purpose-specific alt text; meaning is not color-only.
- Static geometry must have zero overlaps and zero out-of-bounds visuals.
- Forecasts must be labelled analytical scenarios, not company guidance.
- Preserve the qualified names `Calculated EBITDA Proxy`, `Adjusted PAT`, and `Organic FCF`.
