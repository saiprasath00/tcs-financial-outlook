# TCS Financial Dashboard — Baseline Audit

Audit date: 2026-10-19  
Scope: untouched source-to-output baseline before any semantic-model or PBIR redesign.

## Copy integrity

- Source: `work/tcs_pbip_source/TCS_Financial_Dashboard/`
- Working output: `outputs/TCS_Financial_Dashboard_Professional/`
- Source files copied: 60
- Source/output file hash mismatches before this audit file was added: 0
- Workbook: `Data/TCS_Historical_Financials.xlsx`
- Source workbook SHA-256: `24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9`
- Output workbook SHA-256: `24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9`

The copied baseline is byte-for-byte identical to all 60 source files. This audit document is the sole additional file.

## Project references

| Layer | Reference | Resolved target / setting |
|---|---|---|
| PBIP entry point | `TCS_Financial_Dashboard.pbip` → `artifacts[0].report.path` | `TCS_Financial_Dashboard.Report` |
| Report definition | `TCS_Financial_Dashboard.Report/definition.pbir` → `datasetReference.byPath.path` | `../TCS_Financial_Dashboard.SemanticModel` |
| Report format version | `definition.pbir` | `4.0` |
| Semantic model format version | `TCS_Financial_Dashboard.SemanticModel/definition.pbism` | `4.2` |
| Model culture | `definition/model.tmdl` | `en-US` |
| Source-query culture | `definition/model.tmdl` | `en-IN` |
| Active page | `definition/pages/pages.json` | `executive` |
| Page order | `definition/pages/pages.json` | `executive`, `trend`, `scenario`, `detail` |

Model table references in `definition/model.tmdl`:

1. `Historical Financials`
2. `Scenario Assumptions`
3. `Scenario Selector`
4. `Forecast Year`
5. `Forecast Timeline`
6. `Forecast Model`

## Existing four-page geometry

All four pages use a 1280 × 720 canvas with `FitToPage`. A strict rectangle-intersection test found **zero positive-area visual overlaps**, and every visual is fully within its page bounds. Touching edges would not count as overlap; none of the listed visual rectangles intrudes into another.

### Executive Overview (`executive`)

10 visuals; 0 overlaps; 0 out-of-bounds visuals.

| Visual | Type | X | Y | Width | Height |
|---|---:|---:|---:|---:|---:|
| `executive_header` | textbox | 24 | 12 | 680 | 70 |
| `executive_scenario` | slicer | 704 | 12 | 260 | 70 |
| `executive_year` | slicer | 980 | 12 | 276 | 70 |
| `executive_forecast_revenue` | cardVisual | 24 | 106 | 294 | 108 |
| `executive_forecast_ebitda` | cardVisual | 330 | 106 | 294 | 108 |
| `executive_forecast_net_profit` | cardVisual | 636 | 106 | 294 | 108 |
| `executive_forecast_free_cash_flow` | cardVisual | 942 | 106 | 294 | 108 |
| `executive_selected_context` | textbox | 24 | 232 | 1232 | 52 |
| `executive_selected_forecast_outputs` | clusteredColumnChart | 24 | 304 | 780 | 368 |
| `executive_summary` | lineChart | 824 | 304 | 432 | 368 |

### Trend & Profitability (`trend`)

5 visuals; 0 overlaps; 0 out-of-bounds visuals.

| Visual | Type | X | Y | Width | Height |
|---|---:|---:|---:|---:|---:|
| `trend_header` | textbox | 24 | 16 | 1232 | 58 |
| `trend_revenue` | lineChart | 24 | 100 | 594 | 270 |
| `trend_ebitda` | lineChart | 642 | 100 | 614 | 270 |
| `trend_profit_cash` | clusteredColumnChart | 24 | 405 | 765 | 270 |
| `trend_historical_detail` | tableEx | 815 | 405 | 441 | 270 |

### Scenario & Drivers (`scenario`)

8 visuals; 0 overlaps; 0 out-of-bounds visuals.

| Visual | Type | X | Y | Width | Height |
|---|---:|---:|---:|---:|---:|
| `scenario_header` | textbox | 24 | 16 | 680 | 58 |
| `scenario_scenario` | slicer | 704 | 12 | 260 | 70 |
| `scenario_year` | slicer | 980 | 12 | 276 | 70 |
| `scenario_forecast_revenue` | cardVisual | 24 | 105 | 285 | 100 |
| `scenario_forecast_ebitda_margin` | cardVisual | 326 | 105 | 285 | 100 |
| `scenario_note` | textbox | 636 | 105 | 620 | 100 |
| `scenario_comparison` | clusteredColumnChart | 24 | 230 | 740 | 445 |
| `scenario_drivers` | tableEx | 788 | 230 | 468 | 445 |

### Financial Detail (`detail`)

9 visuals; 0 overlaps; 0 out-of-bounds visuals.

| Visual | Type | X | Y | Width | Height |
|---|---:|---:|---:|---:|---:|
| `detail_header` | textbox | 24 | 16 | 680 | 58 |
| `detail_scenario` | slicer | 704 | 12 | 260 | 70 |
| `detail_year` | slicer | 980 | 12 | 276 | 70 |
| `detail_forecast_revenue` | cardVisual | 24 | 105 | 294 | 100 |
| `detail_forecast_ebitda` | cardVisual | 330 | 105 | 294 | 100 |
| `detail_forecast_net_profit` | cardVisual | 636 | 105 | 294 | 100 |
| `detail_forecast_free_cash_flow` | cardVisual | 942 | 105 | 294 | 100 |
| `detail_metric_values` | barChart | 24 | 230 | 600 | 445 |
| `detail_detail_table` | tableEx | 650 | 230 | 606 | 445 |

## Power BI Desktop availability

`PBIDesktop.exe` is not exposed on `PATH`, the conventional Program Files locations are absent, and no classic uninstall-registry entry was found. However, the Microsoft Store package **is installed**:

- Package: `Microsoft.MicrosoftPowerBIDesktop_2.159.883.0_x64__8wekyb3d8bbwe`
- Version: `2.159.883.0`
- Executable found under the package install directory: `bin/PBIDesktop.exe`

Accordingly, a claim that Power BI Desktop is wholly absent would be inaccurate. The classic/PATH-visible installation is absent, while the Store-packaged application is present. No Desktop launch or save operation was performed during this baseline story.

## Baseline conclusion

The source project is preserved, the output baseline is intact, references resolve coherently, the four existing pages have no geometric overlap or page-boundary violations, and no redesign has yet been applied.
