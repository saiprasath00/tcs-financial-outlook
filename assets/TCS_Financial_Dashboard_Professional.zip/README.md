# TCS Financial Outlook Dashboard

Professional four-page Power BI Project (PBIP) for TCS historical analysis and FY2027–FY2028 scenario planning. The report separates reported history, the FY2026 actual bridge, and analytical Base/Bull/Bear scenarios.

## Open the dashboard

1. Keep this entire folder together.
2. Open `TCS_Financial_Dashboard.pbip` in Power BI Desktop.
3. If the folder moved, open **Transform data > Manage parameters**, edit `WorkbookPath` to the absolute path of `Data/TCS_Historical_Financials.xlsx`, then select **Close & Apply**.
4. Select **Refresh**.

The packaged `WorkbookPath` already targets the workbook in this delivered folder. Only one parameter needs changing after relocation.

## Pages

| Page | Purpose |
|---|---|
| Executive Overview | Scenario and year controls, four headline forecast KPIs, selected context, growth, and the actual/forecast revenue timeline. |
| Trend & Profitability | FY2018–FY2025 revenue, EBITDA, net-profit margin, profit, FCF, and auditable values. |
| Scenario & Drivers | Three-scenario comparison for the selected year plus forecast-implied drivers. |
| Financial Detail | Detail-only FY2025 historical selector, monetary metric comparison, source units, and selected forecast outputs. |

Default forecast context is **Base Case / FY2028**. Scenario values are sensitivity cases created for this dashboard; they are not TCS guidance, audited forecasts, or consensus estimates.

## Evidence status

- **Passed:** source/output workbook identity; 88 historical rows; 30 primary assumption rows; model and report references; 34 visuals; four 1280×720 pages; zero static overlaps/out-of-bounds visuals; unique tab order; alt text; six forecast states; FY2026 bridge.
- **Passed in Power BI’s local engine:** imported-table refresh, DAX execution, all six Scenario × Forecast Year states, 11-year timeline, and FY2026 actual/forecast equality.
- **Still requires human Desktop inspection:** rendered text clipping, chart readability, UI cross-filter behavior, cross-page slicer sync, tooltips, keyboard traversal, and save/reopen persistence.

See [VALIDATION_REPORT.md](VALIDATION_REPORT.md) for exact results, [FINANCIAL_SOURCE_LEDGER.md](FINANCIAL_SOURCE_LEDGER.md) for figure-level provenance, and [DESKTOP_CHECKLIST.md](DESKTOP_CHECKLIST.md) for the final visual acceptance pass.

## Data and definitions

- Historical source: `Data/TCS_Historical_Financials.xlsx`, FY2018–FY2025.
- Workbook SHA-256: `24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9`.
- FY2026 model baseline: Revenue ₹267,021 Cr; EBIT ₹66,838 Cr; Adjusted PAT ₹52,820 Cr; EPS bridge ₹145.99; shares 361.81 Cr.
- FY2027–FY2028: fixed Base/Bull/Bear analytical outputs.
- `Calculated EBITDA Proxy`, `Adjusted PAT`, and `Organic FCF` are explicit model definitions; do not relabel them as unqualified reported metrics.
- `Forecast Driver` values are ratios implied by fixed scenario outputs. They are explanatory, not editable forecast assumptions.

The workbook contains a cached `Dashboard!B1 = #VALUE!`. The imported historical and primary-assumption ranges do not depend on that cell. The source workbook is preserved byte-for-byte.

## Project contents

- `TCS_Financial_Dashboard.Report/` — PBIR report definition.
- `TCS_Financial_Dashboard.SemanticModel/` — TMDL semantic model.
- `Queries/` and `Measures/` — readable M and DAX mirrors.
- `tools/validate_project.py` — deterministic static and evidence validator.
- `tools/run_runtime_probe.ps1` — live local Analysis Services/DAX probe.
- `validation-results.json` and `runtime-validation.json` — machine-readable evidence.
- `previews/` — conceptual geometry previews, clearly labelled as non-Desktop renders.

## Re-run validation

From the parent workspace, run:

```powershell
python .\outputs\TCS_Financial_Dashboard_Professional\tools\validate_project.py `
  --project .\outputs\TCS_Financial_Dashboard_Professional `
  --source .\work\tcs_pbip_source\TCS_Financial_Dashboard `
  --output .\outputs\TCS_Financial_Dashboard_Professional\validation-results.json
```

The command returns exit code `0` only when every mandatory check passes. Packaging evidence is completed after the ZIP is built.

## Primary-source reconciliation

- [TCS Integrated Annual Report 2025–26](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf)
- [TCS Integrated Annual Report 2024–25](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2024-25/ar/annual-report-2024-2025.pdf)

FY2018–FY2024 values were structurally checked against the supplied workbook, not independently re-performed against every annual report.
