# Data Dictionary

## Provenance classes

| Class | Period | Meaning |
|---|---|---|
| Supplied historical workbook | FY2018–FY2025 | Static user-provided history; 88 imported metric/year rows. |
| Official actual bridge | FY2026 | Model baseline reconciled to TCS reporting, with adjusted/proxy definitions kept explicit. |
| Analytical scenario | FY2027–FY2028 | Fixed Base/Bull/Bear sensitivity outputs; not company guidance. |
| Forecast-implied driver | FY2027–FY2028 | Ratio calculated from fixed scenario outputs; not an input assumption. |

## Historical Financials

Grain: one `Particulars` × `Fiscal Year` row. Expected rows: 11 × 8 = 88.

| Column | Type | Definition |
|---|---|---|
| Particulars | Text | Metric name from the audited allowlist below. |
| Fiscal Year | Text | FY2018 through FY2025. |
| Fiscal Year Sort | Whole number | Numeric year used for chronological sorting. |
| Amount | Decimal number | Source value in the unit declared by `Unit`. |
| Unit | Text | `₹ Cr`, `₹`, count, or source-specific unit. |

Historical metric allowlist: Revenue; EBITDA; EBIT; Other Income (Net); Net Profit; EPS - Diluted (INR); Shares Outstanding; Employees; Depreciation; Capex; Free Cash Flow.

Key measures: Revenue, EBITDA, Net Profit, Free Cash Flow, Historical EBITDA Margin, Historical Net Profit Margin, Actual Revenue, and Scenario Forecast Revenue.

## Forecast Model

Grain: one `Scenario` × `Fiscal Year` row. Expected rows: 7.

| Column | Unit | Definition |
|---|---|---|
| Scenario | Text | `Actual` for FY2026; Base Case, Bull Case, or Bear Case for FY2027–FY2028. |
| Fiscal Year | Text | FY2026–FY2028. |
| Fiscal Year Sort | Whole number | Chronological sort key. |
| Revenue | ₹ Cr | Revenue output. |
| EBIT | ₹ Cr | EBIT output. |
| Calculated EBITDA Proxy | ₹ Cr | EBIT plus modelled depreciation/amortization proxy. |
| Adjusted PAT | ₹ Cr | Adjusted profit-after-tax model output. Not interchangeable with reported attributable profit. |
| CFO | ₹ Cr | Cash flow from operations output; intentionally blank for FY2026 actual. |
| Organic FCF | ₹ Cr | Organic free-cash-flow output; intentionally blank for FY2026 actual. |
| EPS | ₹/share | Stored adjusted EPS output. |
| Shares Outstanding (Cr) | Cr shares | Share-count basis for the EPS bridge. |

Headline FY2026 contract: Revenue 267,021; EBIT 66,838; Calculated EBITDA Proxy 72,398; Adjusted PAT 52,820; EPS 145.99; Shares 361.81 Cr.

## Scenario Assumptions

Grain: one `Parameter` × `Scenario` row. Expected rows: 10 × 3 = 30.

| Column | Type | Definition |
|---|---|---|
| Parameter | Text | One of the ten primary workbook keys below. |
| Scenario | Text | Base Case, Bull Case, or Bear Case. |
| Value | Decimal number | Workbook assumption value. |
| Unit | Text | `%` except Shares Outstanding, which uses `Cr`. |
| Notes | Text | Workbook context where present. |

Primary keys: Revenue Growth FY26; Revenue Growth FY27; Revenue Growth FY28; EBITDA Margin FY26; EBITDA Margin FY27; EBITDA Margin FY28; Implied Net Profit Margin (Est.); Tax Rate; Depreciation (% of Rev); Shares Outstanding (Cr).

These imported assumptions provide audit context. The fixed `Forecast Model` values are not dynamically recalculated from this table.

## Forecast Driver

Disconnected presentation table with eight rows.

| Key | Label | Unit | Calculation |
|---|---|---|---|
| REV_YOY | Revenue growth vs prior year | % | (Selected-year revenue − same-scenario prior-year revenue) / prior-year revenue. `DIVIDE` returns blank when the denominator is zero. |
| REV_CUM_FY26 | Cumulative revenue change vs FY2026 | % | (Selected-year revenue − FY2026 actual revenue) / FY2026 actual revenue. `DIVIDE` returns blank when the denominator is zero. |
| EBIT_MARGIN | Implied EBIT margin | % | EBIT / revenue. |
| DA_TO_REVENUE | Implied D&A / revenue | % | (Calculated EBITDA Proxy − EBIT) / revenue. |
| PAT_MARGIN | Implied adjusted PAT margin | % | Adjusted PAT / revenue. |
| CFO_TO_PAT | Implied CFO / adjusted PAT | x | CFO / Adjusted PAT. |
| CFO_FCF_GAP_TO_REVENUE | Implied (CFO − FCF) / revenue | % | (CFO − Organic FCF) / revenue. |
| EPS_BRIDGE | Adjusted PAT / shares EPS bridge | ₹/share | Adjusted PAT / Shares Outstanding (Cr). |

## Selector and timeline tables

| Table | Values | Behavior |
|---|---|---|
| Scenario Selector | Base Case, Bull Case, Bear Case | Disconnected; default Base Case. |
| Forecast Year | FY2027, FY2028 | Disconnected; default FY2028. |
| Forecast Timeline | FY2018–FY2028 | Disconnected axis; actual series ends FY2026 and scenario series begins with the equal FY2026 bridge. |

## Source integrity and scope

- Workbook SHA-256: `24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9`.
- Cached `Dashboard!B1 = #VALUE!` exists, but imported ranges have no dependency on it.
- FY2025 revenue, total profit for year, and rounded diluted EPS were reconciled to the TCS 2024–25 annual report.
- FY2026 adjusted-performance fields were reconciled to the TCS 2025–26 annual report.
- FY2018–FY2024 were checked structurally against the workbook, not independently re-performed against every primary report.
