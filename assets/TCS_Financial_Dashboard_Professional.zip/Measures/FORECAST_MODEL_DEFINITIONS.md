# Forecast model definitions and validation

## Scope and provenance

`Forecast Model` is a fixed, disconnected analytical table. It contains one FY2026 baseline row labelled `Actual` and six planning rows: Base Case, Bull Case and Bear Case for FY2027 and FY2028. The scenario rows are analytical outputs supplied with this project; they are not TCS guidance and are not calculated from the imported `Scenario Assumptions` table.

The FY2026 baseline uses the project's reconciled annual-report values: Revenue ₹267,021 Cr, EBIT ₹66,838 Cr, Adjusted PAT ₹52,820 Cr, diluted EPS ₹145.99 and shares outstanding 361.81 Cr. `Adjusted PAT` is the adjusted performance definition used by this model; it must not be relabelled as reported consolidated profit or profit attributable to shareholders. `Calculated EBITDA Proxy` is EBIT plus the model's D&A-like bridge (₹5,560 Cr in FY2026); it is a calculated proxy, not a separately reported TCS guidance metric. FY2026 CFO and Organic FCF are unknown in the fixed table and intentionally remain blank.

Primary FY2026 source: [TCS Integrated Annual Report 2025–26](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf). The project documentation records the adjusted/reporting distinction; Desktop refresh does not independently re-fetch this source.

## Decision-measure contract

- `Forecast Revenue YoY`: FY2027 versus FY2026 actual; FY2028 versus FY2027 of the same scenario.
- `Forecast Cumulative Revenue Change vs FY2026`: selected forecast revenue versus the invariant FY2026 actual baseline. This is cumulative baseline change, not FY2028 YoY.
- `Forecast EBIT Margin`: EBIT / Revenue.
- `Forecast D&A to Revenue`: (Calculated EBITDA Proxy − EBIT) / Revenue.
- `Forecast Adjusted PAT Margin`: Adjusted PAT / Revenue.
- `Forecast CFO to Adjusted PAT`: CFO / Adjusted PAT.
- `Forecast CFO Less FCF to Revenue`: (CFO − Organic FCF) / Revenue.
- `Forecast EPS Bridge`: Adjusted PAT / Shares Outstanding (Cr), in ₹/share.
- `Forecast EPS Bridge Variance`: calculated bridge less the stored EPS; intended as a validation diagnostic.

The disconnected `Forecast Driver` table maps its eight display keys to these authoritative numeric measures. Unknown driver keys and driver totals return blank. Unit-aware display formatting is separate from the numeric measure.

## Fixed-table arithmetic evidence

Static extraction on 2026-10-19 found 7 rows, 7 unique Scenario×Fiscal Year keys, exactly 1 `Actual` FY2026 row and exactly 6 forecast rows. The scenario/year domain is Base/Bull/Bear × FY2027/FY2028. FY2026 Revenue is a single invariant baseline. FY2026 CFO and Organic FCF were both confirmed blank.

| Scenario | Year | Revenue | YoY | Cumulative vs FY2026 | EBIT margin | D&A / revenue | Adjusted PAT margin | CFO / PAT | (CFO−FCF) / revenue | EPS bridge | Stored EPS | Abs. difference |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Base Case | FY2027 | 295,058 | 10.50% | 10.50% | 24.20% | 1.75% | 19.10% | 1.0000x | 1.60% | 155.7613 | 155.8 | 0.0387 |
| Base Case | FY2028 | 312,762 | 6.00% | 17.13% | 24.70% | 1.75% | 19.40% | 1.0000x | 1.60% | 167.7013 | 167.7 | 0.0013 |
| Bull Case | FY2027 | 300,399 | 12.50% | 12.50% | 24.80% | 1.70% | 19.60% | 1.0500x | 1.80% | 162.7318 | 162.7 | 0.0318 |
| Bull Case | FY2028 | 327,435 | 9.00% | 22.63% | 25.50% | 1.70% | 20.10% | 1.0500x | 1.80% | 181.9021 | 181.9 | 0.0021 |
| Bear Case | FY2027 | 288,383 | 8.00% | 8.00% | 23.50% | 1.85% | 18.40% | 0.9500x | 1.40% | 146.6571 | 146.7 | 0.0429 |
| Bear Case | FY2028 | 297,034 | 3.00% | 11.24% | 23.80% | 1.90% | 18.60% | 0.9500x | 1.50% | 152.6989 | 152.7 | 0.0011 |

Maximum absolute EPS bridge difference is ₹0.0429/share, within the ±₹0.10 acceptance tolerance. The fixed seven-row table therefore remains unchanged.

## TMDL parse evidence

Official TOM/TMDL deserialization passed after these measure changes using Microsoft package `Microsoft.AnalysisServices.NetCore.retail.amd64` version `19.84.1` and `TmdlSerializer.DeserializeDatabaseFromFolder` against `TCS_Financial_Dashboard.SemanticModel/definition`. Result: compatibility level 1606, 7 tables, 0 parse diagnostics/exceptions. `Historical Financials` contains 41 measures; `Forecast Driver` contains 2 measures. This establishes TMDL syntax and model deserialization. Import refresh and DAX execution were subsequently validated against Power BI Desktop's local Analysis Services engine; visual rendering and UI behavior still require the Desktop checklist.
