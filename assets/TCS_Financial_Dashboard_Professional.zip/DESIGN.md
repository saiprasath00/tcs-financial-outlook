# Design

## Source of truth

**Status:** Active — 18 October 2026.  
**Product surface:** Power BI Desktop report `TCS_Financial_Dashboard.pbip`, using the supplied Excel workbook for FY2018–FY2025 history, TCS FY2026 reporting for the actual baseline, and an explicit analytical scenario table for FY2027–FY2028.  
**Evidence reviewed:** existing PBIP/TMDL/PBIR definitions, static non-rendered layout previews, Microsoft’s PBIR/TMDL documentation, and TCS FY2025–26 reporting. The FY2027–FY2028 figures are analytical scenarios, not company guidance.

## Brand

**Personality:** executive, clear, analytical, confident, and approachable.  
**Trust signals:** visible reporting period, scenario label, clear units, documented forecast assumptions, consistent number formats.  
**Avoid:** rainbow colouring, decorative clutter, unexplained abbreviations, dense tables as a landing page, or colour-only meaning.

## Product goals

- Let leaders understand historical performance, forecast direction, drivers, and financial detail in one short decision flow.
- Make scenario and fiscal-year choices immediately visible and applicable across forecast KPI cards and the Executive forecast-output chart.
- Distinguish historical actuals from scenario-led forecast outputs.
- Provide a report that stays readable when viewed on a typical 16:9 Power BI canvas.

**Non-goals:** live market prices, operational transaction monitoring, or pretending a local Excel snapshot is a streaming feed.  
**Success signals:** four navigable pages, scenario/year controls, concise KPI context, readable charts, accessible labels, and no broken visual bindings when opened in Power BI Desktop.

## Personas and jobs

**Executive sponsor:** understand direction, risks, and headline economics in under two minutes.  
**Finance analyst:** compare historical performance, validate assumptions, and inspect individual financial metrics.  
**Planning lead:** use Bull/Base/Bear choices to communicate forecast sensitivity and decision drivers.

## Information architecture

The report uses four 16:9 pages in this order:

1. **Executive Overview** — scenario/year controls, four selected forecast KPIs, planning context, growth context, and actual-to-scenario revenue runway.
2. **Trend & Profitability** — historical revenue, margins, profit, FCF, and auditable values.
3. **Scenario & Drivers** — selected forecast KPIs, an isolated Bull/Base/Bear comparison, and implied driver ratios.
4. **Financial Detail** — selected forecast KPIs plus a detail-only FY2025 historical metric selector and audit table.

Page tabs are the primary navigation. Executive Overview, Scenario & Drivers, and Financial Detail repeat the fixed Scenario / Fiscal Year controls. Their initial state is **Base Case / FY2028**; forecast KPI visuals explicitly consume those disconnected selector tables. The year selector contains only **FY2027 and FY2028** because FY2026 is actual. Executive Overview places both selectors above the KPI row and renders an active planning-context label plus a forecast-output chart using the same selections.

## Design principles

- One page, one decision: overview, trend, drivers, then details.
- Headlines before evidence; evidence before granular data.
- Preserve a visual grammar: title strip, KPI cards, analytical panels, supporting notes.
- Use labels and titles rather than relying on colour or legend position.
- Keep controls close to the decision they change and show their selected state.

## Visual language

- **Canvas:** warm off-white `#F8FAFC`; panels and cards white.
- **Text:** navy `#0F172A`; supporting text slate `#475569`.
- **Metric palette:** Revenue blue `#2563EB`; EBITDA teal `#0F766E`; Net Profit violet `#7C3AED`; Free Cash Flow amber `#D97706`.
- **Scenario palette:** Bull blue-green, Base blue, Bear rose; every scenario is also named in the legend.
- **Typography:** Segoe UI; page title 24–28 pt, visual title 12–14 pt, KPI callout 24–30 pt.
- **Spacing:** 16–24 px grid; panels use 12 px-radius visual treatment where Desktop supports it; generous whitespace.
- **Charts:** direct labels/tooltips, zero-baseline for column charts, no 3D effects, restrained gridlines.

## Components

- **Header:** report title, page label, and subtitle.
- **KPI card:** one metric, clear title, white surface, colour used as an accent not the sole signal.
- **Scenario control:** single-select dropdown/table with Bull/Base/Bear labels.
- **Year control:** single-select fiscal-year dropdown.
- **Analytical panel:** titled chart/table with concise description, white surface, and explicit unit.
- **Navigation:** Power BI page tabs in the defined IA order.

## Accessibility

- Target WCAG 2.2 AA contrast for text and meaningful UI surfaces.
- Do not convey scenario or metric identity with colour alone; use names and titles.
- Keep a logical keyboard tab sequence: header, controls, KPI cards, charts, table.
- Ensure all visual titles use plain language and numbers retain units/decimal conventions.
- Avoid motion-dependent information and use default Power BI focus states.

## Responsive behavior

The primary target is Desktop 16:9. At reduced width, Power BI's responsive canvas and visual headers retain the hierarchy: controls precede charts; detail tables are the first element to scroll. Phone layout is out of scope until real Desktop validation completes.

## Interaction states

- **Loading:** Power BI native progress state; show no invented "real-time" status.
- **Empty/filter state:** retain visual title and explain that no data matches the active control.
- **Error:** visual errors must expose source/field details and be fixed at the model-binding level.
- **Success:** selected scenario/year visibly remain in the slicer, appear in the active planning-context label, and update every selected-forecast KPI and Executive forecast-output chart.
- **Disabled:** unsupported forecast filtering is described in the page subtitle rather than presenting a misleading disabled control.

## Content voice

Direct, finance-literate, and plain. Use "Revenue", "Calculated EBITDA proxy", "Adjusted PAT", "Organic FCF", "Scenario", and "Forecast Year" consistently. State forecast caveats as facts: "FY26 is actual; FY27–FY28 are analytical scenarios, not TCS guidance."

## Implementation constraints

- Keep the supplied workbook unchanged.
- Bind only to declared TMDL tables and measures; validate each projection against the semantic model before release. `Scenario Selector` and `Forecast Year` are intentionally disconnected tables: forecast measures must consume them through `SELECTEDVALUE`, not relationships.
- Only FY2027–FY2028 appear in the Forecast Year selector. FY2026 remains a fixed actual baseline and never changes with scenario selection.
- Use PBIR files supported by the installed Power BI Desktop version.
- The local workbook is a refreshable snapshot. OneDrive/SharePoint or gateway configuration is required for supported ongoing refresh; API/streaming requires a separately authorised source.
- Final visual validation must be performed in Power BI Desktop; PBIR schema/static validation cannot prove rendering.

## Forecast evidence and labelling

- FY2026 actual Revenue (₹267,021 Cr), EBIT (₹66,838 Cr), and adjusted PAT (₹52,820 Cr) are anchored to the [TCS Integrated Annual Report 2025–26](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf).
- The current-period context is cross-checked against [TCS FY2026 Q4/full-year results](https://www.tcs.com/who-we-are/newsroom/press-release/tcs-financial-results-q4-fy-2026) and [TCS FY2027 Q1 results](https://www.tcs.com/who-we-are/newsroom/press-release/tcs-financial-results-q1-fy-2027).
- FY2027 and FY2028 Base/Bull/Bear values are analyst-built sensitivity cases. They are deliberately labelled **analytical scenarios** and must not be presented as management guidance, consensus, or audited actuals.
- Calculated EBITDA proxy is an analytical bridge supplied with the forecast model; it is not a separately reported TCS guidance metric.

## Open questions

- [ ] Which Power BI Desktop build and launch location should be used for final on-device validation? **Owner:** user/device. **Impact:** blocks rendered proof only.
- [ ] Should a OneDrive/SharePoint location or gateway be configured for recurring refresh? **Owner:** report owner. **Impact:** determines refresh deployment, not the local report design.
- [ ] Should the report be branded with TCS corporate assets beyond the neutral executive palette? **Owner:** report sponsor. **Impact:** optional visual refinement.
