# Power BI Desktop Acceptance Checklist

Static and live semantic-model evidence already passes. Complete this checklist in the visible Power BI Desktop UI before final publication.

## Open and refresh

- [ ] Open `TCS_Financial_Dashboard.pbip` without recovery or compatibility errors.
- [ ] Confirm `WorkbookPath` points to this folder's `Data/TCS_Historical_Financials.xlsx`.
- [ ] Select **Refresh** and confirm both imports finish without errors.
- [ ] Confirm Executive Overview opens as the landing page.

## Rendering

- [ ] All four pages render at 1280×720 with no overlaps, clipped titles, hidden controls, or scrollbars.
- [ ] KPI values fit and use correct units: ₹ Cr, %, x, or ₹/share.
- [ ] Calculated EBITDA Proxy, Adjusted PAT, and Organic FCF remain explicitly labelled.
- [ ] Scenario EBITDA margin renders as a percentage, not currency.
- [ ] Actual and scenario revenue series have distinct legend labels; FY2026 is visibly the actual bridge.
- [ ] Tables remain readable and do not display meaningless mixed-unit totals.
- [ ] Colors, focus indicators, and text remain legible at 100% and 125% Windows scaling.

## Slicer sync

1. Open **View > Sync slicers**.
2. Select the Executive Scenario slicer; enable **Sync** and **Visible** for Executive, Scenario, and Detail.
3. Repeat for Forecast Year.
4. Do not sync the Detail Historical Year slicer.

- [ ] Scenario persists across Executive, Scenario, and Detail.
- [ ] Forecast Year persists across Executive, Scenario, and Detail.
- [ ] Detail Historical Year stays page-local.
- [ ] After saving and reopening, sync still behaves the same.

If Desktop cannot round-trip supported sync metadata, leave cross-page sync documented as deferred; do not hand-edit undocumented `syncGroup` properties.

## Six forecast states

Test Base, Bull, and Bear for FY2027 and FY2028.

- [ ] Selected context text matches the visible slicers.
- [ ] Revenue, Calculated EBITDA Proxy, Adjusted PAT, and Organic FCF update.
- [ ] Driver values update with truthful units.
- [ ] Scenario comparison keeps all three cases visible for the selected year.
- [ ] Clicking the comparison chart does not filter selected-result cards or drivers.
- [ ] The full revenue timeline remains FY2018–FY2028; year selection does not truncate it.
- [ ] Historical/FY2026 actual values do not change with scenario selection.

Restore **Base Case / FY2028** after testing.

## Detail and historical behavior

- [ ] Detail Historical Year defaults to FY2025.
- [ ] It filters only the monetary metric chart and historical detail table.
- [ ] It does not filter forecast cards, scenario/year slicers, or other pages.
- [ ] The metric chart excludes EPS, shares, and employees.
- [ ] Trend shows the full FY2018–FY2025 range and has no year slicer.

## Accessibility and interaction

- [ ] Tab order follows the visible reading order on every page.
- [ ] Screen reader announces useful alt text for every visual.
- [ ] Tooltips state metric, year, unit, and actual/scenario status.
- [ ] Keyboard users can reach and operate every slicer and chart.
- [ ] Focus mode and Show as a table provide usable alternatives.

## Persistence and sign-off

- [ ] Save the project, close Desktop, reopen the PBIP, and refresh again.
- [ ] Repeat Base/FY2028 and one non-default state.
- [ ] Confirm slicer sync and page order survived round-trip.
- [ ] Record Desktop version, tester, date, and any screenshots outside the source project.

Sign-off: ____________________  Date: ____________________  Desktop version: ____________________
