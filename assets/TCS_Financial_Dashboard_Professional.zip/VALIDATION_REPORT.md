# Validation Report

Generated evidence date: 19–20 October 2026 (Asia/Calcutta).

## Release result

**Static and live semantic-model checks pass. Final visual acceptance remains pending a human Desktop walkthrough.**

`validation-results.json` is the machine-readable static/evidence report. `runtime-validation.json` contains the live Power BI local Analysis Services results.

## Passed evidence

| Area | Result | Evidence |
|---|---|---|
| Workbook identity | PASS | Source and output SHA-256 both equal `24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9`. |
| Historical import | PASS | 88 rows and 88 unique metric/year keys; all required values numeric. |
| Primary assumptions | PASS | 30 rows and 30 unique parameter/scenario keys; exact 10-key allowlist. |
| Workbook error isolation | PASS | Cached `Dashboard!B1 = #VALUE!`; no imported-range dependency found. |
| Project references | PASS | PBIP, PBIR, model, page, and JSON references resolve. |
| Model bindings | PASS | Seven tables; all statically discoverable PBIR fields resolve. |
| Official TMDL parser | PASS | `TmdlSerializer.DeserializeDatabaseFromFolder` returned `TMDL_OK model=Model tables=7 expressions=1` using Analysis Services 19.84.1. |
| Query safety | PASS | Single required `WorkbookPath`; both imports use consumed fail-fast guards; standalone/deployed M parity. |
| Forecast grain | PASS | One FY2026 Actual row plus six scenario/year planning rows. |
| Forecast arithmetic | PASS | Six combinations; EPS bridge absolute error ≤ ₹0.10/share. |
| Live import refresh | PASS | Historical 88; Assumptions 30; Forecast 7; Timeline 11; Driver 8. |
| Live DAX | PASS | Six scenario/year states returned with revenue, EBITDA proxy, adjusted PAT, FCF, growth, margins, cash ratios, and EPS bridge. |
| Timeline | PASS | Actual nonblank FY2018–FY2026; scenario nonblank FY2026–FY2028; FY2026 equality for all scenarios. |
| Geometry | PASS | Four 1280×720 pages; 34 visuals; no static overlaps or out-of-bounds rectangles. |
| Interaction declarations | PASS | Endpoints resolve; selector defaults, comparison isolation, and Detail-only historical filtering match contract. |
| Accessibility declarations | PASS | Unique tab order, alt text on every visual, and primary color contrast ≥ 4.5:1. |

The live probe used `Microsoft.AnalysisServices.AdomdClient 19.118.3` against the Power BI Desktop local catalog. It issued a full refresh for both imported tables before running DAX.

## Not yet verified

These require visible Desktop inspection and must not be inferred from JSON geometry or DAX results:

- Actual visual rendering, label clipping, legend readability, and responsive behavior.
- Chart click interactions, selector usability, tooltips, focus mode, and keyboard traversal.
- Cross-page Scenario/Forecast Year slicer sync.
- Save, close, reopen persistence.
- Remote official JSON Schema validation.

## Accuracy boundary

- FY2025 headlines and FY2026 baseline were reconciled against TCS annual reports.
- FY2026 adjusted PAT/EPS and Calculated EBITDA Proxy use explicitly labelled adjusted/proxy definitions. They are not silently substituted for reported attributable profit or reported EBITDA.
- FY2027–FY2028 figures are dashboard sensitivity cases, not external forecasts.
- FY2018–FY2024 values are structurally verified against the supplied workbook but were not independently re-performed against each annual report.
- Figure-level source terminology, derivations, and unresolved provenance boundaries are recorded in `FINANCIAL_SOURCE_LEDGER.md`.

## Static validator

Run from the parent workspace:

```powershell
python .\outputs\TCS_Financial_Dashboard_Professional\tools\validate_project.py `
  --project .\outputs\TCS_Financial_Dashboard_Professional `
  --source .\work\tcs_pbip_source\TCS_Financial_Dashboard `
  --output .\outputs\TCS_Financial_Dashboard_Professional\validation-results.json
```

Exit code `0` is the mandatory local gate. Review `DESKTOP_CHECKLIST.md` before calling the visual product complete.
