// Power Query: Scenario Assumptions
// Uses the shared WorkbookPath parameter and imports only the audited primary assumption block.
let
    ExpectedParameters = {
        "Revenue Growth FY26", "Revenue Growth FY27", "Revenue Growth FY28",
        "EBITDA Margin FY26", "EBITDA Margin FY27", "EBITDA Margin FY28",
        "Implied Net Profit Margin (Est.)", "Tax Rate",
        "Depreciation (% of Rev)", "Shares Outstanding (Cr)"
    },
    ExpectedScenarios = {"Base Case", "Bull Case", "Bear Case"},
    ExpectedHeaders = List.Combine({{"Parameter"}, ExpectedScenarios, {"Unit", "Notes"}}),
    ExpectedKeys = List.Combine(List.Transform(ExpectedParameters, (ParameterName) => List.Transform(ExpectedScenarios, (ScenarioName) => ParameterName & "|" & ScenarioName))),
    Source = Excel.Workbook(File.Contents(WorkbookPath), null, true),
    AvailableSheets = Table.Column(Table.SelectRows(Source, each [Kind] = "Sheet"), "Item"),
    CheckedWorkbook =
        if List.Contains(AvailableSheets, "Assumptions") then Source
        else error Error.Record("ScenarioAssumptions.MissingSheet", "The workbook is missing the required Assumptions worksheet.", [WorkbookPath = WorkbookPath, RequiredSheet = "Assumptions", AvailableSheets = AvailableSheets]),
    AssumptionsSheet = CheckedWorkbook{[Item = "Assumptions", Kind = "Sheet"]}[Data],
    CheckedSheetShape =
        if Table.RowCount(AssumptionsSheet) >= 19 then AssumptionsSheet
        else error Error.Record("ScenarioAssumptions.HeaderRowMissing", "Assumptions must contain the promoted header row at worksheet row 9 and ten primary data rows.", [WorkbookPath = WorkbookPath, Sheet = "Assumptions", ExpectedHeaderRow = 9, AvailableRows = Table.RowCount(AssumptionsSheet)]),
    RawHeaderValues = List.Transform(Record.FieldValues(CheckedSheetShape{8}), each if _ = null then null else Text.Trim(Text.From(_))),
    NamedRawHeaders = List.Select(RawHeaderValues, each _ <> null and _ <> ""),
    DuplicateHeaders = List.Select(List.Distinct(NamedRawHeaders), (HeaderName) => List.Count(List.Select(NamedRawHeaders, each _ = HeaderName)) > 1),
    HeaderRow = Table.PromoteHeaders(Table.Skip(CheckedSheetShape, 8), [PromoteAllScalars = true]),
    AvailableHeaders = Table.ColumnNames(HeaderRow),
    MissingHeaders = List.Difference(ExpectedHeaders, AvailableHeaders),
    CheckedHeaders =
        if List.IsEmpty(MissingHeaders) and List.IsEmpty(DuplicateHeaders) then HeaderRow
        else error Error.Record("ScenarioAssumptions.InvalidHeaders", "Assumptions does not have the required unique promoted headers.", [Sheet = "Assumptions", MissingHeaders = MissingHeaders, DuplicateHeaders = DuplicateHeaders, AvailableHeaders = AvailableHeaders]),
    PrimaryBlock = Table.FirstN(CheckedHeaders, 10),
    PrimaryRows = Table.SelectRows(PrimaryBlock, each List.Contains(ExpectedParameters, [Parameter])),
    PrimaryColumns = Table.SelectColumns(PrimaryRows, ExpectedHeaders, MissingField.Error),
    ParameterCounts = Table.Group(PrimaryColumns, {"Parameter"}, {{"RowCount", each Table.RowCount(_), Int64.Type}}),
    DuplicateParameterRows = Table.SelectRows(ParameterCounts, each [RowCount] <> 1),
    ActualParameters = Table.Column(ParameterCounts, "Parameter"),
    MissingParameters = List.Difference(ExpectedParameters, ActualParameters),
    UnexpectedParameters = List.Difference(ActualParameters, ExpectedParameters),
    CheckedParameters =
        if Table.RowCount(PrimaryColumns) = 10 and Table.IsEmpty(DuplicateParameterRows) and List.IsEmpty(MissingParameters) and List.IsEmpty(UnexpectedParameters) then PrimaryColumns
        else error Error.Record("ScenarioAssumptions.InvalidPrimaryParameterSet", "Assumptions must contain each of the ten approved primary parameter rows exactly once.", [ExpectedRowCount = 10, ActualRowCount = Table.RowCount(PrimaryColumns), DuplicateParameters = Table.ToRecords(DuplicateParameterRows), MissingParameters = MissingParameters, UnexpectedParameters = UnexpectedParameters]),
    UnitContractRows = Table.SelectRows(
        CheckedParameters,
        each let ExpectedUnit = if [Parameter] = "Shares Outstanding (Cr)" then "Cr" else "%", ActualUnit = try Text.Trim(Text.From([Unit])) otherwise null in ActualUnit <> ExpectedUnit
    ),
    CheckedUnits =
        if Table.IsEmpty(UnitContractRows) then CheckedParameters
        else error Error.Record("ScenarioAssumptions.InvalidUnit", "Primary assumption units must be % except Shares Outstanding (Cr), which must be Cr.", [InvalidRows = Table.ToRecords(Table.SelectColumns(UnitContractRows, {"Parameter", "Unit"}))]),
    Unpivoted = Table.Unpivot(CheckedUnits, ExpectedScenarios, "Scenario", "Value"),
    KeyCounts = Table.Group(Unpivoted, {"Parameter", "Scenario"}, {{"RowCount", each Table.RowCount(_), Int64.Type}}),
    DuplicateKeyRows = Table.SelectRows(KeyCounts, each [RowCount] <> 1),
    ActualKeys = List.Transform(Table.ToRecords(KeyCounts), each Text.From([Parameter]) & "|" & Text.From([Scenario])),
    MissingKeys = List.Difference(ExpectedKeys, ActualKeys),
    UnexpectedKeys = List.Difference(ActualKeys, ExpectedKeys),
    CheckedKeys =
        if Table.RowCount(Unpivoted) = 30 and Table.IsEmpty(DuplicateKeyRows) and List.IsEmpty(MissingKeys) and List.IsEmpty(UnexpectedKeys) then Unpivoted
        else error Error.Record("ScenarioAssumptions.InvalidParameterScenarioGrain", "Assumptions must yield exactly 30 unique rows: ten approved parameters by three scenarios.", [ExpectedRowCount = 30, ActualRowCount = Table.RowCount(Unpivoted), DuplicateKeys = Table.ToRecords(DuplicateKeyRows), MissingKeys = MissingKeys, UnexpectedKeys = UnexpectedKeys]),
    ParsedRows = Table.AddColumn(
        CheckedKeys,
        "__Validation",
        each let ParsedValue = try Number.From([Value], "en-IN"), ParsedUnit = try Text.Trim(Text.From([Unit])), ParsedNotes = try if [Notes] = null then "" else Text.From([Notes]) in [ValueNumber = if ParsedValue[HasError] then null else ParsedValue[Value], ValueHasError = ParsedValue[HasError], ValueError = if ParsedValue[HasError] then ParsedValue[Error][Message] else null, UnitText = if ParsedUnit[HasError] then null else ParsedUnit[Value], UnitHasError = ParsedUnit[HasError], NotesText = if ParsedNotes[HasError] then null else ParsedNotes[Value]],
        type record
    ),
    ExpandedValidation = Table.ExpandRecordColumn(ParsedRows, "__Validation", {"ValueNumber", "ValueHasError", "ValueError", "UnitText", "UnitHasError", "NotesText"}),
    InvalidValueRows = Table.SelectRows(ExpandedValidation, each [ValueHasError] or [UnitHasError] or [ValueNumber] = null or [UnitText] = null or [UnitText] = ""),
    CheckedRequiredValues =
        if Table.IsEmpty(InvalidValueRows) then ExpandedValidation
        else error Error.Record("ScenarioAssumptions.InvalidRequiredValue", "Every approved parameter-scenario row must contain a numeric Value and nonblank Unit.", [InvalidRows = Table.ToRecords(Table.SelectColumns(InvalidValueRows, {"Parameter", "Scenario", "ValueError", "UnitText"}))]),
    SelectedColumns = Table.SelectColumns(CheckedRequiredValues, {"Parameter", "Scenario", "ValueNumber", "UnitText", "NotesText"}),
    RenamedColumns = Table.RenameColumns(SelectedColumns, {{"ValueNumber", "Value"}, {"UnitText", "Unit"}, {"NotesText", "Notes"}}),
    Typed = Table.TransformColumnTypes(RenamedColumns, {{"Parameter", type text}, {"Scenario", type text}, {"Value", type number}, {"Unit", type text}, {"Notes", type text}}, "en-IN")
in
    Typed
