// Power Query: Historical Financials
// WorkbookPath is the single required text parameter defined in SemanticModel/definition/expressions.tmdl.
let
    ExpectedSheets = {"Historical_Data", "Assumptions"},
    ExpectedMetrics = {
        "Revenue", "EBITDA", "EBIT", "Other Income (Net)", "Net Profit",
        "EPS - Diluted (INR)", "Shares Outstanding", "Employees", "Depreciation",
        "Capex", "Free Cash Flow"
    },
    ExpectedFiscalYears = {"FY2018", "FY2019", "FY2020", "FY2021", "FY2022", "FY2023", "FY2024", "FY2025"},
    ExpectedHeaders = List.Combine({{"Particulars"}, ExpectedFiscalYears, {"Unit"}}),
    ExpectedKeys = List.Combine(
        List.Transform(
            ExpectedMetrics,
            (MetricName) => List.Transform(ExpectedFiscalYears, (FiscalYear) => MetricName & "|" & FiscalYear)
        )
    ),
    Source = Excel.Workbook(File.Contents(WorkbookPath), null, true),
    AvailableSheets = Table.Column(Table.SelectRows(Source, each [Kind] = "Sheet"), "Item"),
    MissingSheets = List.Difference(ExpectedSheets, AvailableSheets),
    CheckedWorkbook =
        if List.IsEmpty(MissingSheets) then
            Source
        else
            error Error.Record(
                "HistoricalImport.MissingSheet",
                "The workbook is missing one or more required worksheets.",
                [WorkbookPath = WorkbookPath, MissingSheets = MissingSheets, AvailableSheets = AvailableSheets]
            ),
    HistoricalSheet = CheckedWorkbook{[Item = "Historical_Data", Kind = "Sheet"]}[Data],
    CheckedSheetShape =
        if Table.RowCount(HistoricalSheet) >= 4 then
            HistoricalSheet
        else
            error Error.Record(
                "HistoricalImport.HeaderRowMissing",
                "Historical_Data must contain the promoted header row at worksheet row 4.",
                [WorkbookPath = WorkbookPath, Sheet = "Historical_Data", ExpectedHeaderRow = 4, AvailableRows = Table.RowCount(HistoricalSheet)]
            ),
    RawHeaderValues = List.Transform(
        Record.FieldValues(CheckedSheetShape{3}),
        each if _ = null then null else Text.Trim(Text.From(_))
    ),
    NamedRawHeaders = List.Select(RawHeaderValues, each _ <> null and _ <> ""),
    DuplicateHeaders = List.Select(
        List.Distinct(NamedRawHeaders),
        (HeaderName) => List.Count(List.Select(NamedRawHeaders, each _ = HeaderName)) > 1
    ),
    HeaderRow = Table.PromoteHeaders(Table.Skip(CheckedSheetShape, 3), [PromoteAllScalars = true]),
    AvailableHeaders = Table.ColumnNames(HeaderRow),
    MissingHeaders = List.Difference(ExpectedHeaders, AvailableHeaders),
    CheckedHeaders =
        if List.IsEmpty(MissingHeaders) and List.IsEmpty(DuplicateHeaders) then
            HeaderRow
        else
            error Error.Record(
                "HistoricalImport.InvalidHeaders",
                "Historical_Data does not have the required unique promoted headers.",
                [Sheet = "Historical_Data", MissingHeaders = MissingHeaders, DuplicateHeaders = DuplicateHeaders, AvailableHeaders = AvailableHeaders]
            ),
    CoreMetrics = Table.SelectRows(CheckedHeaders, each List.Contains(ExpectedMetrics, [Particulars])),
    KeepColumns = Table.SelectColumns(CoreMetrics, ExpectedHeaders, MissingField.Error),
    Unpivoted = Table.Unpivot(KeepColumns, ExpectedFiscalYears, "Fiscal Year", "Amount"),
    KeyCounts = Table.Group(
        Unpivoted,
        {"Particulars", "Fiscal Year"},
        {{"RowCount", each Table.RowCount(_), Int64.Type}}
    ),
    DuplicateKeyRows = Table.SelectRows(KeyCounts, each [RowCount] <> 1),
    ActualKeys = List.Transform(
        Table.ToRecords(KeyCounts),
        each Text.From([Particulars]) & "|" & Text.From([Fiscal Year])
    ),
    MissingKeys = List.Difference(ExpectedKeys, ActualKeys),
    UnexpectedKeys = List.Difference(ActualKeys, ExpectedKeys),
    CheckedKeys =
        if Table.RowCount(Unpivoted) = 88 and Table.IsEmpty(DuplicateKeyRows) and List.IsEmpty(MissingKeys) and List.IsEmpty(UnexpectedKeys) then
            Unpivoted
        else
            error Error.Record(
                "HistoricalImport.InvalidMetricYearGrain",
                "Historical_Data must yield exactly 88 unique rows: 11 approved metrics by 8 fiscal years.",
                [
                    ExpectedRowCount = 88,
                    ActualRowCount = Table.RowCount(Unpivoted),
                    DuplicateKeys = Table.ToRecords(DuplicateKeyRows),
                    MissingKeys = MissingKeys,
                    UnexpectedKeys = UnexpectedKeys
                ]
            ),
    ParsedRows = Table.AddColumn(
        CheckedKeys,
        "__Validation",
        each
            let
                ParsedAmount = try Number.From([Amount], "en-IN"),
                ParsedUnit = try Text.Trim(Text.From([Unit]))
            in
                [
                    AmountValue = if ParsedAmount[HasError] then null else ParsedAmount[Value],
                    AmountHasError = ParsedAmount[HasError],
                    AmountError = if ParsedAmount[HasError] then ParsedAmount[Error][Message] else null,
                    UnitValue = if ParsedUnit[HasError] then null else ParsedUnit[Value],
                    UnitHasError = ParsedUnit[HasError],
                    UnitError = if ParsedUnit[HasError] then ParsedUnit[Error][Message] else null
                ],
        type record
    ),
    ExpandedValidation = Table.ExpandRecordColumn(
        ParsedRows,
        "__Validation",
        {"AmountValue", "AmountHasError", "AmountError", "UnitValue", "UnitHasError", "UnitError"}
    ),
    TypeErrorRows = Table.SelectRows(ExpandedValidation, each [AmountHasError] or [UnitHasError]),
    NullRows = Table.SelectRows(
        ExpandedValidation,
        each not [AmountHasError] and not [UnitHasError] and ([AmountValue] = null or [UnitValue] = null or [UnitValue] = "")
    ),
    CheckedRequiredValues =
        if Table.IsEmpty(TypeErrorRows) and Table.IsEmpty(NullRows) then
            ExpandedValidation
        else
            error Error.Record(
                "HistoricalImport.InvalidRequiredValue",
                "Every approved metric-year row must contain a numeric Amount and a nonblank Unit.",
                [
                    TypeErrors = Table.ToRecords(Table.SelectColumns(TypeErrorRows, {"Particulars", "Fiscal Year", "AmountError", "UnitError"})),
                    NullOrBlankValues = Table.ToRecords(Table.SelectColumns(NullRows, {"Particulars", "Fiscal Year", "AmountValue", "UnitValue"}))
                ]
            ),
    SelectedColumns = Table.SelectColumns(CheckedRequiredValues, {"Particulars", "Fiscal Year", "AmountValue", "UnitValue"}),
    RenamedColumns = Table.RenameColumns(SelectedColumns, {{"AmountValue", "Amount"}, {"UnitValue", "Unit"}}),
    Typed = Table.TransformColumnTypes(
        RenamedColumns,
        {{"Particulars", type text}, {"Unit", type text}, {"Fiscal Year", type text}, {"Amount", type number}},
        "en-IN"
    ),
    AddedSort = Table.AddColumn(Typed, "Fiscal Year Sort", each Number.FromText(Text.AfterDelimiter([Fiscal Year], "FY")), Int64.Type)
in
    AddedSort
