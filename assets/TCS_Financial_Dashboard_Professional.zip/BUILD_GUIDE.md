# Build and Maintenance Guide

## Requirements

- Power BI Desktop with PBIP support.
- Python 3 with `openpyxl` and `Pillow` to run the supplied validation and preview tools.
- .NET 8 SDK only when rebuilding the optional live runtime probe.

## Relocate the workbook

`WorkbookPath` is the single source-path parameter for both imported tables.

1. Open `TCS_Financial_Dashboard.pbip`.
2. Select **Transform data > Manage parameters**.
3. Set `WorkbookPath` to the absolute path of `Data/TCS_Historical_Financials.xlsx`.
4. Select **Close & Apply**, then **Refresh**.

For source-controlled edits, the parameter is declared in `TCS_Financial_Dashboard.SemanticModel/definition/expressions.tmdl`. Do not hard-code separate paths in either table partition or standalone query.

## Source contracts

Refresh intentionally fails when the workbook violates these contracts:

- Required sheets exist.
- Historical import contains exactly 11 allowlisted metrics × 8 fiscal years = 88 unique numeric rows.
- Scenario import contains exactly 10 allowlisted parameters × 3 scenarios = 30 unique numeric rows.
- Required keys are present, unique, and typed.
- Standalone files in `Queries/` remain equivalent to their deployed partition expressions.

The source workbook is immutable. Correct source defects through a documented transformation, never by silently changing the delivered workbook.

## Model conventions

- `Scenario Selector`, `Forecast Year`, `Forecast Timeline`, and `Forecast Driver` are disconnected tables.
- Default forecast context is Base Case / FY2028.
- FY2026 is an actual bridge. `Actual Revenue` is populated for FY2018–FY2026; `Scenario Forecast Revenue` is populated for FY2026–FY2028.
- Scenario comparison excludes the `Actual` row and retains all Base/Bull/Bear cases.
- The Detail Historical Year selector filters only `detail_metric_values` and `detail_detail_table`.
- Do not add undocumented PBIR synchronization properties. Author and test slicer sync through Desktop.

## Edit safely

1. Change semantic definitions before report bindings.
2. Keep `Measures/Dashboard_Measures.dax` aligned with authoritative TMDL.
3. Preserve the 1280×720 canvas, 24 px outer margin, and 16 px gutters.
4. Give every visual a unique `tabOrder` and an `altText` value.
5. Run the static validator.
6. Open the PBIP in Desktop, refresh, and complete `DESKTOP_CHECKLIST.md`.
7. Save, close, reopen, and repeat the critical scenario checks before release.

## Generate conceptual previews

```powershell
python .\tools\generate_layout_previews.py
```

The images show PBIR geometry and design intent only. They are not screenshots and cannot prove rendering.

## Run static validation

From the parent workspace:

```powershell
python .\outputs\TCS_Financial_Dashboard_Professional\tools\validate_project.py `
  --project .\outputs\TCS_Financial_Dashboard_Professional `
  --source .\work\tcs_pbip_source\TCS_Financial_Dashboard `
  --output .\outputs\TCS_Financial_Dashboard_Professional\validation-results.json
```

## Run the live model probe

With the PBIP open in Desktop, obtain its local Analysis Services port, then run:

```powershell
.\tools\run_runtime_probe.ps1 -Port <port> -Output runtime-validation.json -RefreshImports
```

The probe validates import refresh, row counts, DAX outputs, timeline nonblank sets, and the FY2026 bridge. It does not automate chart rendering or UI behavior.
