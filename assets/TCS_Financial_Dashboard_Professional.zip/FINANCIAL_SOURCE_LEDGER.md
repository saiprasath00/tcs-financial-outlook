# Financial Source Ledger

This ledger separates externally reported figures, derived values, and dashboard-only analytical assumptions. Currency is ₹ crore unless stated otherwise.

| Model item | Value | Classification | Source / derivation | Status |
|---|---:|---|---|---|
| FY2026 Revenue | 267,021 | Reported actual | TCS Integrated Annual Report 2025–26, Financial Performance Overview (page 88), “Revenue from operations” | Exact numeric match |
| FY2026 EBIT | 66,838 | Reported actual | Same table, “Earnings before interest and taxes (before other income)” | Exact numeric match |
| FY2026 Adjusted PAT | 52,820 | Model label applied to reported attributable PAT value | Same table, “Profit after tax attributable to shareholders” | Numeric match; terminology differs, so definition identity is not claimed |
| FY2026 EPS bridge | ₹145.99/share | Reported bridge anchor | Same table, earnings per share | Exact numeric match |
| FY2026 shares | 361.81 crore shares | Derived | 52,820 ÷ 145.99 | Derived, not a directly sourced share-count disclosure |
| FY2026 Calculated EBITDA Proxy | 72,398 | Analytical proxy | EBIT 66,838 + model bridge 5,560 | EBIT sourced; 5,560 bridge model-supplied and not independently verified |
| FY2025 Revenue | 255,324 | Reported actual | TCS Integrated Annual Report 2024–25 | Exact numeric match |
| FY2025 attributable PAT | 48,553 | Reported actual | TCS Integrated Annual Report 2024–25 | Exact numeric match |
| FY2025 diluted EPS | ₹134.19/share | Reported actual | TCS Integrated Annual Report 2024–25 | Exact numeric match |
| FY2018–FY2024 history | Supplied workbook values | User-provided dataset | `Data/TCS_Historical_Financials.xlsx` | Structure, types, uniqueness, and row count passed; not independently re-performed against every annual report |
| FY2027–FY2028 Base/Bull/Bear outputs | Six scenario-year rows | Dashboard sensitivity cases | `Forecast Scenario` model table | Not TCS guidance, audited forecasts, or consensus estimates |
| Forecast Driver ratios | Eight calculated ratios | Derived explanation | Ratios implied by fixed scenario outputs | Explanatory only; not editable assumptions |

Primary sources:

- [TCS Integrated Annual Report 2025–26](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf)
- [TCS Integrated Annual Report 2024–25](https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2024-25/ar/annual-report-2024-2025.pdf)

The report intentionally retains the qualified labels `Calculated EBITDA Proxy`, `Adjusted PAT`, and `Organic FCF`. They must not be presented as unqualified reported metrics.
