#!/usr/bin/env python3
"""Create honest static layout previews from PBIR page/visual geometry."""

from __future__ import annotations

import json
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
PAGES = ROOT / "TCS_Financial_Dashboard.Report" / "definition" / "pages"
OUT = ROOT / "previews"

FONT = Path("C:/Windows/Fonts/segoeui.ttf")
FONT_SEMIBOLD = Path("C:/Windows/Fonts/seguisb.ttf")


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_SEMIBOLD if bold and FONT_SEMIBOLD.exists() else FONT
    return ImageFont.truetype(str(path), size=size) if path.exists() else ImageFont.load_default()


def literal_values(node, property_name: str) -> list[str]:
    found = []
    if isinstance(node, dict):
        if property_name in node:
            try:
                found.append(str(node[property_name]["expr"]["Literal"]["Value"]).strip("'"))
            except (KeyError, TypeError):
                pass
        for value in node.values():
            found.extend(literal_values(value, property_name))
    elif isinstance(node, list):
        for value in node:
            found.extend(literal_values(value, property_name))
    return found


def visual_title(data: dict) -> str:
    visual = data.get("visual", {})
    try:
        return str(
            visual["visualContainerObjects"]["title"][0]["properties"]["text"]
            ["expr"]["Literal"]["Value"]
        ).strip("'")
    except (KeyError, IndexError, TypeError):
        pass
    return data["name"].replace("_", " ").title()


def rounded(draw: ImageDraw.ImageDraw, box, fill, outline="#E2E8F0", radius=10, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def draw_visual(draw: ImageDraw.ImageDraw, data: dict, page_name: str):
    p = data["position"]
    x, y, w, h = p["x"], p["y"], p["width"], p["height"]
    box = (x, y, x + w, y + h)
    visual_type = data.get("visual", {}).get("visualType", "group")
    name = data["name"]
    title = visual_title(data)

    if "header" in name:
        rounded(draw, box, "#0F172A", outline="#0F172A", radius=12)
        page_titles = {
            "executive": "TCS Financial Outlook • Executive Overview",
            "trend": "TCS Financial Outlook • Trend & Profitability",
            "scenario": "TCS Financial Outlook • Scenario & Drivers",
            "detail": "TCS Financial Outlook • Financial Detail",
        }
        draw.text((x + 18, y + max(8, (h - 30) // 2)), page_titles[page_name], font=font(23, True), fill="#FFFFFF")
        return

    if visual_type == "slicer":
        rounded(draw, box, "#E0F2FE", outline="#93C5FD", radius=9)
        draw.text((x + 12, y + 8), title, font=font(12, True), fill="#0F172A")
        if name.endswith("_scenario"):
            selected = "Base Case"
        elif "historical_year" in name:
            selected = "FY2025"
        else:
            selected = "FY2028"
        draw.text((x + 12, y + 34), selected + "  ▾", font=font(13), fill="#1D4ED8")
        return

    accent = "#2563EB"
    lower = name.lower()
    if "ebitda" in lower or "margin" in lower:
        accent = "#0F766E"
    elif "net_profit" in lower or "pat" in lower:
        accent = "#7C3AED"
    elif "cash" in lower or "free_cash_flow" in lower:
        accent = "#B45309"
    elif "driver" in lower:
        accent = "#0891B2"

    rounded(draw, box, "#FFFFFF", outline="#CBD5E1", radius=10)
    draw.rounded_rectangle((x, y, x + 6, y + h), radius=4, fill=accent)
    draw.text((x + 16, y + 10), title[:70], font=font(12, True), fill="#0F172A")

    if visual_type in {"card", "cardVisual", "multiRowCard"}:
        values = {
            "ebitda_margin": "26.4%", "growth": "6.0%", "revenue": "₹312,762 Cr",
            "ebitda": "₹82,726 Cr", "net_profit": "₹60,676 Cr", "free_cash_flow": "₹55,672 Cr",
        }
        value = next((v for k, v in values.items() if k in lower), "Base Case • FY2028")
        draw.text((x + 16, y + max(38, h // 2 - 8)), value, font=font(min(28, max(16, h // 4)), True), fill=accent)
    elif visual_type in {"tableEx", "table", "matrix"}:
        cols = 3 if w > 420 else 2
        left = x + 16
        top = y + 42
        for row in range(5):
            yy = top + row * max(24, (h - 52) // 6)
            draw.line((left, yy, x + w - 14, yy), fill="#E2E8F0", width=1)
            for col in range(1, cols):
                xx = left + col * (w - 30) // cols
                draw.line((xx, yy, xx, min(y + h - 10, yy + 20)), fill="#E2E8F0", width=1)
        draw.text((left, top + 5), "Auditable values • units • context", font=font(10), fill="#475569")
    elif visual_type in {"lineChart", "areaChart"}:
        left, top, right, bottom = x + 38, y + 52, x + w - 20, y + h - 28
        draw.line((left, bottom, right, bottom), fill="#94A3B8", width=1)
        draw.line((left, top, left, bottom), fill="#94A3B8", width=1)
        pts = [(left + i * (right - left) / 10, bottom - ((i * 7 + (i % 3) * 13) % max(40, bottom - top - 10))) for i in range(11)]
        draw.line(pts, fill="#2563EB", width=4, joint="curve")
        draw.line(pts[-3:], fill="#0F766E", width=4, joint="curve")
    elif visual_type in {"barChart", "clusteredColumnChart", "columnChart", "lineClusteredColumnComboChart"}:
        left, top, right, bottom = x + 42, y + 52, x + w - 20, y + h - 28
        draw.line((left, bottom, right, bottom), fill="#94A3B8", width=1)
        count = 6 if w > 550 else 4
        gap = max(8, (right - left) // (count * 3))
        bar_w = max(12, (right - left - gap * (count + 1)) // count)
        for i in range(count):
            height = (bottom - top) * (0.35 + 0.1 * (i % 4))
            bx = left + gap + i * (bar_w + gap)
            draw.rounded_rectangle((bx, bottom - height, bx + bar_w, bottom), radius=3, fill=["#2563EB", "#0F766E", "#7C3AED", "#B45309"][i % 4])
    else:
        draw.text((x + 16, y + min(44, h - 22)), "Decision context and model caveat", font=font(11), fill="#475569")


def render(page_name: str):
    page = json.loads((PAGES / page_name / "page.json").read_text(encoding="utf-8-sig"))
    image = Image.new("RGB", (page["width"], page["height"]), "#F1F5F9")
    draw = ImageDraw.Draw(image)
    visuals = []
    for path in sorted((PAGES / page_name / "visuals").glob("*/visual.json")):
        visuals.append(json.loads(path.read_text(encoding="utf-8-sig")))
    for visual in sorted(visuals, key=lambda item: item["position"].get("z", 0)):
        draw_visual(draw, visual, page_name)

    label = "STATIC LAYOUT PREVIEW — NOT A POWER BI RENDER"
    label_box = (830, 686, 1272, 714)
    rounded(draw, label_box, "#FEF3C7", outline="#B45309", radius=6)
    draw.text((842, 692), label, font=font(12, True), fill="#92400E")
    image.save(OUT / f"{page_name}-layout.png", optimize=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for page in ["executive", "trend", "scenario", "detail"]:
        render(page)
        print(OUT / f"{page}-layout.png")


if __name__ == "__main__":
    main()
