using System.Data;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AnalysisServices.AdomdClient;

static object? Clean(object value) => value == DBNull.Value || value is double d && (double.IsNaN(d) || double.IsInfinity(d)) ? null : value;
static List<Dictionary<string, object?>> Query(AdomdConnection connection, string dax)
{
    using var command = connection.CreateCommand(); command.CommandText = dax;
    using var reader = command.ExecuteReader(); var rows = new List<Dictionary<string, object?>>();
    while (reader.Read()) { var row = new Dictionary<string, object?>(); for (var i = 0; i < reader.FieldCount; i++) row[reader.GetName(i)] = Clean(reader.GetValue(i)); rows.Add(row); }
    return rows;
}
static double? Num(Dictionary<string, object?> row, string key) => row.TryGetValue(key, out var value) && value is not null ? Convert.ToDouble(value, CultureInfo.InvariantCulture) : null;
static string? Txt(Dictionary<string, object?> row, string key) => row.TryGetValue(key, out var value) && value is not null ? value.ToString() : null;
static bool Near(double? actual, double expected, double tolerance) => actual is not null && Math.Abs(actual.Value - expected) <= tolerance;
static string HashFile(string path) { using var stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)); }

var named = args.Select((value, index) => (value, index)).ToDictionary(item => item.value, item => item.index);
if (!named.TryGetValue("--port", out var portIndex) || portIndex + 1 >= args.Length || !named.TryGetValue("--output", out var outputIndex) || outputIndex + 1 >= args.Length)
{ Console.Error.WriteLine("Usage: runtime_probe --port <port> --output <json-path> [--refresh-imports]"); return 2; }

var port = args[portIndex + 1];
var output = Path.GetFullPath(args[outputIndex + 1]);
var refreshRequested = args.Contains("--refresh-imports");
var projectRoot = Path.GetDirectoryName(output)!;
var modelDefinition = Path.Combine(projectRoot, "TCS_Financial_Dashboard.SemanticModel", "definition");
var modelFiles = Directory.Exists(modelDefinition)
    ? Directory.GetFiles(modelDefinition, "*.tmdl", SearchOption.AllDirectories).OrderBy(path => Path.GetRelativePath(modelDefinition, path), StringComparer.Ordinal)
        .ToDictionary(path => Path.GetRelativePath(modelDefinition, path).Replace('\\', '/'), HashFile, StringComparer.Ordinal)
    : new Dictionary<string, string>();
var combinedMaterial = string.Join("\n", modelFiles.Select(item => $"{item.Key}:{item.Value}"));
var combinedModelHash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(combinedMaterial)));
var result = new Dictionary<string, object?>
{
    ["generatedAt"] = DateTimeOffset.Now.ToString("O"), ["dataSource"] = $"localhost:{port}", ["client"] = "Microsoft.AnalysisServices.AdomdClient 19.118.3",
    ["evidenceBoundary"] = "Live local Analysis Services/DAX evidence with fixed expected-value comparisons. No claim of visual rendering, UI interaction, cross-page sync, save/reopen persistence, or injected model mutation.",
    ["modelFileHashes"] = modelFiles, ["combinedModelSha256"] = combinedModelHash,
    ["tolerances"] = new { monetaryCrore = 0.001, ratios = 0.000000001, epsRupee = 0.001 },
};

try
{
    using var discovery = new AdomdConnection($"Data Source=localhost:{port};"); discovery.Open();
    var catalogs = discovery.GetSchemaDataSet("DBSCHEMA_CATALOGS", null);
    var catalog = catalogs.Tables[0].Rows.Cast<DataRow>().Select(row => row["CATALOG_NAME"]?.ToString()).FirstOrDefault(name => !string.IsNullOrWhiteSpace(name));
    discovery.Close(); if (catalog is null) throw new InvalidOperationException("No Analysis Services catalog was exposed.");
    result["catalog"] = catalog;
    using var connection = new AdomdConnection($"Data Source=localhost:{port};Initial Catalog={catalog};"); connection.Open();

    var refreshFailed = false;
    if (refreshRequested)
    {
        try
        {
            using var refresh = connection.CreateCommand();
            refresh.CommandText = $"{{\"refresh\":{{\"type\":\"full\",\"objects\":[{{\"database\":\"{catalog}\",\"table\":\"Historical Financials\"}},{{\"database\":\"{catalog}\",\"table\":\"Scenario Assumptions\"}}]}}}}";
            refresh.CommandTimeout = 180; refresh.ExecuteNonQuery();
            result["refreshAttempt"] = new { status = "PASS", detail = "Full refresh completed for Historical Financials and Scenario Assumptions." };
        }
        catch (Exception ex) { refreshFailed = true; result["refreshAttempt"] = new { status = "FAIL", detail = ex.Message }; }
    }
    else result["refreshAttempt"] = new { status = "NOT VERIFIED", detail = "Refresh was not requested. Run with --refresh-imports for refresh evidence." };

    var tableCounts = Query(connection, """
        EVALUATE ROW("HistoricalRows",COUNTROWS('Historical Financials'),"AssumptionRows",COUNTROWS('Scenario Assumptions'),"ForecastRows",COUNTROWS('Forecast Model'),"TimelineRows",COUNTROWS('Forecast Timeline'),"DriverRows",COUNTROWS('Forecast Driver'))
        """);
    result["tableCounts"] = tableCounts;

    var scenarioOutputs = Query(connection, """
        EVALUATE
        VAR Grid=CROSSJOIN(DATATABLE("ScenarioValue",STRING,{{"Base Case"},{"Bull Case"},{"Bear Case"}}),DATATABLE("YearValue",STRING,{{"FY2027"},{"FY2028"}}))
        RETURN GENERATE(Grid,VAR S=[ScenarioValue] VAR Y=[YearValue] RETURN ROW(
          "Selected Context",CALCULATE([Selected Forecast Context],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Revenue",CALCULATE([Forecast Revenue],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "EBITDA Proxy",CALCULATE([Forecast EBITDA],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Adjusted PAT",CALCULATE([Forecast Net Profit],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Organic FCF",CALCULATE([Forecast Free Cash Flow],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Revenue YoY",CALCULATE([Forecast Revenue YoY],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Cumulative Revenue vs FY2026",CALCULATE([Forecast Cumulative Revenue Change vs FY2026],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "EBIT Margin",CALCULATE([Forecast EBIT Margin],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "D&A to Revenue",CALCULATE([Forecast D&A to Revenue],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Adjusted PAT Margin",CALCULATE([Forecast Adjusted PAT Margin],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "CFO to Adjusted PAT",CALCULATE([Forecast CFO to Adjusted PAT],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "CFO Less FCF to Revenue",CALCULATE([Forecast CFO Less FCF to Revenue],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "EPS Bridge",CALCULATE([Forecast EPS Bridge],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])),
          "Stored EPS",CALCULATE([Forecast EPS],TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year]))))
        ORDER BY [ScenarioValue],[YearValue]
        """);
    result["scenarioYearOutputs"] = scenarioOutputs;

    var timeline = Query(connection, """
        EVALUATE
        VAR Grid=CROSSJOIN(DATATABLE("ScenarioValue",STRING,{{"Base Case"},{"Bull Case"},{"Bear Case"}}),DATATABLE("YearValue",STRING,{{"FY2027"},{"FY2028"}}))
        RETURN GENERATE(Grid,VAR S=[ScenarioValue] VAR Y=[YearValue] RETURN CALCULATETABLE(
          ADDCOLUMNS(ALL('Forecast Timeline'[Fiscal Year Sort],'Forecast Timeline'[Fiscal Year]),"Actual Revenue",[Actual Revenue],"Scenario Forecast Revenue",[Scenario Forecast Revenue]),
          TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])))
        ORDER BY [ScenarioValue],[YearValue],'Forecast Timeline'[Fiscal Year Sort]
        """);
    result["timelineAllSelections"] = timeline;

    var invariant = Query(connection, """
        EVALUATE VAR Scenarios=DATATABLE("ScenarioValue",STRING,{{"Base Case"},{"Bull Case"},{"Bear Case"}})
        RETURN GENERATE(Scenarios,VAR S=[ScenarioValue] RETURN ROW(
          "Actual Revenue",CALCULATE([Actual Revenue],TREATAS({"FY2026"},'Forecast Timeline'[Fiscal Year]),TREATAS({S},'Scenario Selector'[Scenario])),
          "Scenario Forecast Revenue",CALCULATE([Scenario Forecast Revenue],TREATAS({"FY2026"},'Forecast Timeline'[Fiscal Year]),TREATAS({S},'Scenario Selector'[Scenario]))))
        ORDER BY [ScenarioValue]
        """);
    result["fy2026Invariant"] = invariant;

    var driverOutputs = Query(connection, """
        EVALUATE
        VAR Grid=CROSSJOIN(DATATABLE("ScenarioValue",STRING,{{"Base Case"},{"Bull Case"},{"Bear Case"}}),DATATABLE("YearValue",STRING,{{"FY2027"},{"FY2028"}}))
        RETURN GENERATE(Grid,VAR S=[ScenarioValue] VAR Y=[YearValue] RETURN CALCULATETABLE(
          ADDCOLUMNS(ALL('Forecast Driver'[Sort],'Forecast Driver'[Key],'Forecast Driver'[Label],'Forecast Driver'[Unit]),"Driver Numeric",[Forecast Driver Value],"Driver Display",[Forecast Driver Display]),
          TREATAS({S},'Scenario Selector'[Scenario]),TREATAS({Y},'Forecast Year'[Fiscal Year])))
        ORDER BY [ScenarioValue],[YearValue],'Forecast Driver'[Sort]
        """);
    result["driverOutputs"] = driverOutputs;

    var fallbackContexts = Query(connection, """
        EVALUATE ROW(
          "Default Scenario",[Selected Scenario],"Default Year",[Selected Forecast Year],"Default Revenue",[Forecast Revenue],
          "Multi Scenario Fallback",CALCULATE([Selected Scenario],TREATAS({"Base Case","Bull Case"},'Scenario Selector'[Scenario])),
          "Multi Year Fallback",CALCULATE([Selected Forecast Year],TREATAS({"FY2027","FY2028"},'Forecast Year'[Fiscal Year])),
          "Driver Numeric Total",CALCULATE([Forecast Driver Value],REMOVEFILTERS('Forecast Driver')),
          "Driver Display Total",CALCULATE([Forecast Driver Display],REMOVEFILTERS('Forecast Driver')))
        """);
    result["fallbackAndTotalContexts"] = fallbackContexts;

    var fixedRows = new Dictionary<(string Scenario, string Year), Dictionary<string, double>>
    {
        [("Base Case","FY2027")]=new(){{"Revenue",295058},{"EBIT",71404},{"EBITDA",76568},{"PAT",56356},{"CFO",56356},{"FCF",51635},{"EPS",155.8}},
        [("Base Case","FY2028")]=new(){{"Revenue",312762},{"EBIT",77252},{"EBITDA",82726},{"PAT",60676},{"CFO",60676},{"FCF",55672},{"EPS",167.7}},
        [("Bull Case","FY2027")]=new(){{"Revenue",300399},{"EBIT",74499},{"EBITDA",79606},{"PAT",58878},{"CFO",61822},{"FCF",56415},{"EPS",162.7}},
        [("Bull Case","FY2028")]=new(){{"Revenue",327435},{"EBIT",83496},{"EBITDA",89062},{"PAT",65814},{"CFO",69105},{"FCF",63211},{"EPS",181.9}},
        [("Bear Case","FY2027")]=new(){{"Revenue",288383},{"EBIT",67770},{"EBITDA",73105},{"PAT",53062},{"CFO",50409},{"FCF",46372},{"EPS",146.7}},
        [("Bear Case","FY2028")]=new(){{"Revenue",297034},{"EBIT",70694},{"EBITDA",76338},{"PAT",55248},{"CFO",52486},{"FCF",48030},{"EPS",152.7}},
    };
    const double fy26 = 267021, shares = 361.81, moneyTol = 0.001, ratioTol = 0.000000001, epsTol = 0.001;
    var expected = new Dictionary<(string Scenario, string Year), Dictionary<string, double>>();
    foreach (var pair in fixedRows)
    {
        var v=pair.Value; var prior=pair.Key.Year=="FY2027"?fy26:fixedRows[(pair.Key.Scenario,"FY2027")]["Revenue"];
        expected[pair.Key]=new(){["[Revenue]"]=v["Revenue"],["[EBITDA Proxy]"]=v["EBITDA"],["[Adjusted PAT]"]=v["PAT"],["[Organic FCF]"]=v["FCF"],
          ["[Revenue YoY]"]=(v["Revenue"]-prior)/prior,["[Cumulative Revenue vs FY2026]"]=(v["Revenue"]-fy26)/fy26,["[EBIT Margin]"]=v["EBIT"]/v["Revenue"],
          ["[D&A to Revenue]"]=(v["EBITDA"]-v["EBIT"])/v["Revenue"],["[Adjusted PAT Margin]"]=v["PAT"]/v["Revenue"],["[CFO to Adjusted PAT]"]=v["CFO"]/v["PAT"],
          ["[CFO Less FCF to Revenue]"]=(v["CFO"]-v["FCF"])/v["Revenue"],["[EPS Bridge]"]=v["PAT"]/shares,["[Stored EPS]"]=v["EPS"]};
    }

    var metricMismatches = new List<object>();
    foreach (var row in scenarioOutputs)
    {
        var key=(Txt(row,"[ScenarioValue]")??"",Txt(row,"[YearValue]")??"");
        if (!expected.TryGetValue(key,out var exp)){metricMismatches.Add(new{scenario=key.Item1,year=key.Item2,field="row",error="unexpected"});continue;}
        var context=$"Analytical scenario: {key.Item1}  |  Forecast year: {key.Item2}  |  Units: ₹ Cr";
        if(Txt(row,"[Selected Context]")!=context) metricMismatches.Add(new{scenario=key.Item1,year=key.Item2,field="Selected Context",expected=context,actual=Txt(row,"[Selected Context]")});
        foreach(var item in exp){var tol=item.Key is "[Revenue]" or "[EBITDA Proxy]" or "[Adjusted PAT]" or "[Organic FCF]"?moneyTol:item.Key.Contains("EPS")?epsTol:ratioTol; var actual=Num(row,item.Key); if(!Near(actual,item.Value,tol)) metricMismatches.Add(new{scenario=key.Item1,year=key.Item2,field=item.Key,expected=item.Value,actual,tolerance=tol});}
    }
    var scenarioPass=scenarioOutputs.Count==6&&metricMismatches.Count==0;

    var timelineMismatches=new List<object>();
    foreach(var key in fixedRows.Keys)
    {
        var rows=timeline.Where(row=>Txt(row,"[ScenarioValue]")==key.Scenario&&Txt(row,"[YearValue]")==key.Year).ToList();
        var actualYears=rows.Where(row=>Num(row,"[Actual Revenue]")is not null).Select(row=>Txt(row,"Forecast Timeline[Fiscal Year]")).ToHashSet();
        var forecastYears=rows.Where(row=>Num(row,"[Scenario Forecast Revenue]")is not null).Select(row=>Txt(row,"Forecast Timeline[Fiscal Year]")).ToHashSet();
        var expectedActual=Enumerable.Range(2018,9).Select(y=>$"FY{y}").ToHashSet(); var expectedForecast=new HashSet<string?>{"FY2026","FY2027","FY2028"};
        var bridge=rows.SingleOrDefault(row=>Txt(row,"Forecast Timeline[Fiscal Year]")=="FY2026"); var y27=rows.SingleOrDefault(row=>Txt(row,"Forecast Timeline[Fiscal Year]")=="FY2027"); var y28=rows.SingleOrDefault(row=>Txt(row,"Forecast Timeline[Fiscal Year]")=="FY2028");
        if(rows.Count!=11||!actualYears.SetEquals(expectedActual)||!forecastYears.SetEquals(expectedForecast)||bridge is null||!Near(Num(bridge,"[Actual Revenue]"),fy26,moneyTol)||!Near(Num(bridge,"[Scenario Forecast Revenue]"),fy26,moneyTol)||y27 is null||!Near(Num(y27,"[Scenario Forecast Revenue]"),fixedRows[(key.Scenario,"FY2027")]["Revenue"],moneyTol)||y28 is null||!Near(Num(y28,"[Scenario Forecast Revenue]"),fixedRows[(key.Scenario,"FY2028")]["Revenue"],moneyTol)) timelineMismatches.Add(new{scenario=key.Scenario,selectorYear=key.Year,rows=rows.Count,actualYears,forecastYears});
    }
    var timelinePass=timeline.Count==66&&timelineMismatches.Count==0;

    var driverMap=new Dictionary<string,string>{{"REV_YOY","[Revenue YoY]"},{"REV_CUM_FY26","[Cumulative Revenue vs FY2026]"},{"EBIT_MARGIN","[EBIT Margin]"},{"DA_TO_REVENUE","[D&A to Revenue]"},{"PAT_MARGIN","[Adjusted PAT Margin]"},{"CFO_TO_PAT","[CFO to Adjusted PAT]"},{"CFO_FCF_GAP_TO_REVENUE","[CFO Less FCF to Revenue]"},{"EPS_BRIDGE","[EPS Bridge]"}};
    var driverMismatches=new List<object>();
    foreach(var row in driverOutputs){var s=Txt(row,"[ScenarioValue]")??"";var y=Txt(row,"[YearValue]")??"";var k=Txt(row,"Forecast Driver[Key]")??"";if(!expected.TryGetValue((s,y),out var exp)||!driverMap.TryGetValue(k,out var metric)){driverMismatches.Add(new{scenario=s,year=y,key=k,error="unexpected"});continue;}var tol=k=="EPS_BRIDGE"?epsTol:ratioTol;var value=Num(row,"[Driver Numeric]");var display=Txt(row,"[Driver Display]");if(!Near(value,exp[metric],tol)||string.IsNullOrWhiteSpace(display))driverMismatches.Add(new{scenario=s,year=y,key=k,expected=exp[metric],actual=value,display,tolerance=tol});}
    var driverPass=driverOutputs.Count==48&&driverMismatches.Count==0&&driverOutputs.Select(row=>Txt(row,"Forecast Driver[Key]")).ToHashSet().SetEquals(driverMap.Keys);

    var counts=tableCounts.Single();
    var fixedPass=Num(counts,"[ForecastRows]")==7&&Num(counts,"[TimelineRows]")==11&&Num(counts,"[DriverRows]")==8;
    var importPass=Num(counts,"[HistoricalRows]")==88&&Num(counts,"[AssumptionRows]")==30;
    var invariantPass=invariant.Count==3&&invariant.All(row=>Near(Num(row,"[Actual Revenue]"),fy26,moneyTol)&&Near(Num(row,"[Scenario Forecast Revenue]"),fy26,moneyTol));
    var fallback=fallbackContexts.Single();
    var fallbackPass=Txt(fallback,"[Default Scenario]")=="Base Case"&&Txt(fallback,"[Default Year]")=="FY2028"&&Near(Num(fallback,"[Default Revenue]"),312762,moneyTol)&&Txt(fallback,"[Multi Scenario Fallback]")=="Base Case"&&Txt(fallback,"[Multi Year Fallback]")=="FY2028"&&Num(fallback,"[Driver Numeric Total]")is null&&Txt(fallback,"[Driver Display Total]")is null;
    var hashesPass=modelFiles.Count>=9&&modelFiles.Values.All(hash=>hash.Length==64)&&combinedModelHash.Length==64;

    result["comparisonEvidence"]=new{fixedExpectedScenarioRows=6,metricMismatches,timelineMismatches,driverMismatches,expectedTolerance=new{monetaryCrore=moneyTol,ratio=ratioTol,epsRupee=epsTol}};
    result["negativeTests"]=new object[]{
      new{id="N01",status="NOT VERIFIED",detail="Zero-denominator behavior was not injected into the fixed live model. Static DAX uses DIVIDE(Current-Prior, Prior), which preserves BLANK for a zero denominator."},
      new{id="N02",status="NOT VERIFIED",detail="A refresh-failure injection was not performed. The probe code propagates any requested refresh failure to overall FAIL and process exit 1."},
      new{id="N03",status="NOT VERIFIED",detail="Visual rendering, keyboard focus, cross-page slicer sync, and save/reopen persistence remain manual Desktop checks."}};
    result["checks"]=new object[]{
      new{id="R01",status="PASS",detail="Connected to the live local Analysis Services catalog and executed DAX."},
      new{id="R02",status=fixedPass?"PASS":"FAIL",detail=$"Fixed-table counts: Forecast={Num(counts,"[ForecastRows]")}, Timeline={Num(counts,"[TimelineRows]")}, Driver={Num(counts,"[DriverRows]")}."},
      new{id="R03",status=importPass?"PASS":"FAIL",detail=$"Imported-table counts: Historical={Num(counts,"[HistoricalRows]")}, Assumptions={Num(counts,"[AssumptionRows]")}."},
      new{id="R04",status=scenarioPass?"PASS":"FAIL",detail=$"Compared {scenarioOutputs.Count} live scenario/year rows against fixed expected metrics; mismatches={metricMismatches.Count}."},
      new{id="R05",status=timelinePass?"PASS":"FAIL",detail=$"Checked 11 timeline rows for each of six selector combinations; rows={timeline.Count}, mismatches={timelineMismatches.Count}."},
      new{id="R06",status=invariantPass?"PASS":"FAIL",detail="FY2026 actual/forecast bridge equals ₹267,021 Cr for all three scenarios."},
      new{id="R07",status=refreshRequested?(refreshFailed?"FAIL":"PASS"):"NOT VERIFIED",detail=refreshRequested?(refreshFailed?"Requested import refresh failed.":"Requested import refresh completed."):"Import refresh was not requested."},
      new{id="R08",status=driverPass?"PASS":"FAIL",detail=$"Compared numeric and display measures for eight drivers across six selector combinations; rows={driverOutputs.Count}, mismatches={driverMismatches.Count}."},
      new{id="R09",status=fallbackPass?"PASS":"FAIL",detail="Default/multi-select fallbacks resolve to Base Case/FY2028; driver numeric/display totals remain blank."},
      new{id="R10",status=hashesPass?"PASS":"FAIL",detail=$"Recorded SHA-256 for {modelFiles.Count} TMDL files plus a deterministic combined model hash."}};
    var corePass=fixedPass&&importPass&&scenarioPass&&timelinePass&&invariantPass&&driverPass&&fallbackPass&&hashesPass;
    result["status"]=refreshFailed||!corePass?"FAIL":refreshRequested?"PASS":"PARTIAL";
    connection.Close();
}
catch(Exception ex){result["status"]="FAIL";result["error"]=ex.ToString();}

Directory.CreateDirectory(Path.GetDirectoryName(output)!);
File.WriteAllText(output,JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine(JsonSerializer.Serialize(new{status=result["status"],output}));
return result["status"]?.ToString()=="FAIL"?1:0;
