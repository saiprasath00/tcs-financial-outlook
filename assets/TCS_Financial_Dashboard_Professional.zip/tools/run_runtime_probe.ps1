param(
    [Parameter(Mandatory = $true)]
    [int]$Port,
    [string]$Output = "runtime-validation.json",
    [switch]$RefreshImports
)

$projectRoot = Split-Path -Parent $PSScriptRoot
$probeProject = Join-Path $PSScriptRoot "runtime_probe/runtime_probe.csproj"
$outputPath = if ([System.IO.Path]::IsPathRooted($Output)) { $Output } else { Join-Path $projectRoot $Output }

$probeArguments = @("--port", $Port, "--output", $outputPath)
if ($RefreshImports) { $probeArguments += "--refresh-imports" }
dotnet run --project $probeProject --configuration Release -- @probeArguments
exit $LASTEXITCODE
