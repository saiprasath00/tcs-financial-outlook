#!/usr/bin/env python3
"""Deterministic static validator for the TCS Financial Dashboard PBIP project.

This validator proves file, workbook, model-declaration, binding, arithmetic,
layout, interaction, and packaging properties. It deliberately does not claim
Power BI Desktop rendering, Power Query execution, or DAX-engine execution.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import re
import sys
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from openpyxl import load_workbook


EXPECTED_SHA256 = "24B213FC9A429FCFAC49F3A7E59F466F994ABC218DFBA5D82B44DA7B94934FC9"
HISTORICAL_METRICS = [
    "Revenue", "EBITDA", "EBIT", "Other Income (Net)", "Net Profit",
    "EPS - Diluted (INR)", "Shares Outstanding", "Employees",
    "Depreciation", "Capex", "Free Cash Flow",
]
HISTORICAL_YEARS = [f"FY{year}" for year in range(2018, 2026)]
ASSUMPTION_KEYS = [
    "Revenue Growth FY26", "Revenue Growth FY27", "Revenue Growth FY28",
    "EBITDA Margin FY26", "EBITDA Margin FY27", "EBITDA Margin FY28",
    "Implied Net Profit Margin (Est.)", "Tax Rate",
    "Depreciation (% of Rev)", "Shares Outstanding (Cr)",
]
SCENARIOS = ["Base Case", "Bull Case", "Bear Case"]
FORECAST_YEARS = ("FY2027", "FY2028")
REPORT_PAGES = ("executive", "trend", "scenario", "detail")
SELECTOR_PAGES = ("executive", "scenario", "detail")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def normalized_m(text: str) -> str:
    text = re.sub(r"//[^\n]*", "", text)
    return re.sub(r"\s+", "", text)


def excel_numeric(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))


def find_entity_property(node: Any) -> tuple[str | None, str | None]:
    entity = None
    prop = None
    if isinstance(node, dict):
        if "Entity" in node and isinstance(node["Entity"], str):
            entity = node["Entity"]
        if "Property" in node and isinstance(node["Property"], str):
            prop = node["Property"]
        for value in node.values():
            e, p = find_entity_property(value)
            entity = entity or e
            prop = prop or p
    elif isinstance(node, list):
        for value in node:
            e, p = find_entity_property(value)
            entity = entity or e
            prop = prop or p
    return entity, prop


def collect_visual_refs(node: Any, refs: list[tuple[str, str, str]]) -> None:
    if isinstance(node, dict):
        for key, value in node.items():
            if key in {"Column", "Measure"} and isinstance(value, dict):
                entity, prop = find_entity_property(value)
                if entity and prop:
                    refs.append((entity, prop, key.lower()))
            collect_visual_refs(value, refs)
    elif isinstance(node, list):
        for value in node:
            collect_visual_refs(value, refs)


def parse_tmdl_declarations(definition: Path) -> dict[str, dict[str, set[str]]]:
    declarations: dict[str, dict[str, set[str]]] = {}
    for path in sorted(definition.rglob("*.tmdl")):
        table_name = None
        for line in read_text(path).splitlines():
            table_match = re.match(r"^table\s+(?:'([^']+)'|([^\s]+))", line)
            if table_match:
                table_name = table_match.group(1) or table_match.group(2)
                declarations.setdefault(table_name, {"columns": set(), "measures": set()})
                continue
            if not table_name:
                continue
            item_match = re.match(r"^\s+(column|measure)\s+(?:'([^']+)'|([^\s=]+))", line)
            if item_match:
                item_type = "columns" if item_match.group(1) == "column" else "measures"
                name = item_match.group(2) or item_match.group(3)
                declarations[table_name][item_type].add(name)
    return declarations


def literal_value(node: Any, wanted_property: str) -> list[str]:
    values: list[str] = []
    if isinstance(node, dict):
        if wanted_property in node:
            raw = node[wanted_property]
            if isinstance(raw, dict):
                expr = raw.get("expr")
                literal = expr.get("Literal") if isinstance(expr, dict) else None
                if isinstance(literal, dict) and "Value" in literal:
                    values.append(str(literal["Value"]).strip("'"))
        for value in node.values():
            values.extend(literal_value(value, wanted_property))
    elif isinstance(node, list):
        for value in node:
            values.extend(literal_value(value, wanted_property))
    return values


def contrast_ratio(hex_a: str, hex_b: str) -> float:
    def lum(color: str) -> float:
        rgb = [int(color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
        linear = [channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4 for channel in rgb]
        return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]
    light, dark = sorted((lum(hex_a), lum(hex_b)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    project = args.project.resolve()
    source = args.source.resolve()
    output = args.output.resolve()
    checks: list[dict[str, Any]] = []

    def record(check_id: str, title: str, status: str, details: str, evidence: dict[str, Any] | None = None) -> None:
        checks.append({"id": check_id, "title": title, "status": status, "details": details, "evidence": evidence or {}})

    runtime_path = project / "runtime-validation.json"
    runtime: dict[str, Any] = {}
    runtime_errors: list[str] = []
    if runtime_path.exists():
        try:
            runtime = json.loads(read_text(runtime_path))
        except Exception as exc:
            runtime_errors.append(f"runtime-validation.json: {exc}")
    else:
        runtime_errors.append("runtime-validation.json is missing")

    runtime_counts = runtime.get("tableCounts", [{}])[0] if runtime.get("tableCounts") else {}
    runtime_scenarios = {
        (row.get("[ScenarioValue]"), row.get("[YearValue]"))
        for row in runtime.get("scenarioYearOutputs", [])
    }
    expected_runtime_scenarios = {(scenario, year) for scenario in SCENARIOS for year in FORECAST_YEARS}
    runtime_timeline = runtime.get("timelineAllSelections", [])
    runtime_timeline_groups = {
        (scenario, year): [
            row for row in runtime_timeline
            if row.get("[ScenarioValue]") == scenario and row.get("[YearValue]") == year
        ]
        for scenario, year in expected_runtime_scenarios
    }
    runtime_timeline_ok = all(
        len(rows) == 11
        and {row.get("Forecast Timeline[Fiscal Year]") for row in rows if row.get("[Actual Revenue]") is not None}
            == set(HISTORICAL_YEARS + ["FY2026"])
        and {row.get("Forecast Timeline[Fiscal Year]") for row in rows if row.get("[Scenario Forecast Revenue]") is not None}
            == {"FY2026", "FY2027", "FY2028"}
        for rows in runtime_timeline_groups.values()
    ) and len(runtime_timeline) == 66
    runtime_bridge_ok = all(
        row.get("[Actual Revenue]") == 267021 and row.get("[Scenario Forecast Revenue]") == 267021
        for row in runtime.get("fy2026Invariant", [])
    ) and len(runtime.get("fy2026Invariant", [])) == 3
    model_definition_for_hash = project / "TCS_Financial_Dashboard.SemanticModel" / "definition"
    current_model_hashes = {
        path.relative_to(model_definition_for_hash).as_posix(): sha256(path)
        for path in sorted(model_definition_for_hash.rglob("*.tmdl"))
    }
    combined_hash_material = "\n".join(f"{path}:{digest}" for path, digest in current_model_hashes.items())
    current_combined_model_hash = hashlib.sha256(combined_hash_material.encode("utf-8")).hexdigest().upper()
    runtime_negative_tests = runtime.get("negativeTests", [])
    runtime_ok = (
        not runtime_errors
        and runtime.get("status") == "PASS"
        and runtime.get("refreshAttempt", {}).get("status") == "PASS"
        and runtime_counts == {
            "[HistoricalRows]": 88,
            "[AssumptionRows]": 30,
            "[ForecastRows]": 7,
            "[TimelineRows]": 11,
            "[DriverRows]": 8,
        }
        and runtime_scenarios == expected_runtime_scenarios
        and runtime_timeline_ok
        and runtime_bridge_ok
        and runtime.get("modelFileHashes") == current_model_hashes
        and runtime.get("combinedModelSha256") == current_combined_model_hash
        and runtime.get("comparisonEvidence", {}).get("metricMismatches") == []
        and runtime.get("comparisonEvidence", {}).get("timelineMismatches") == []
        and runtime.get("comparisonEvidence", {}).get("driverMismatches") == []
        and len(runtime.get("driverOutputs", [])) == 48
        and len(runtime_negative_tests) >= 3
        and all(test.get("status") == "NOT VERIFIED" for test in runtime_negative_tests)
        and all(check.get("status") == "PASS" for check in runtime.get("checks", []))
    )

    source_book = source / "Data" / "TCS_Historical_Financials.xlsx"
    output_book = project / "Data" / "TCS_Historical_Financials.xlsx"
    source_hash = sha256(source_book) if source_book.exists() else None
    output_hash = sha256(output_book) if output_book.exists() else None
    zip_path = project.parent / f"{project.name}.zip"
    zip_hash = None
    zip_note = "Archive not yet present; G007 packaging check remains pending."
    if zip_path.exists():
        with zipfile.ZipFile(zip_path) as archive:
            members = [name for name in archive.namelist() if name.endswith("Data/TCS_Historical_Financials.xlsx")]
            if len(members) == 1:
                zip_hash = hashlib.sha256(archive.read(members[0])).hexdigest().upper()
                zip_note = "Archive workbook located and hashed."
    hashes_ok = source_hash == output_hash == EXPECTED_SHA256 and (zip_hash in {None, EXPECTED_SHA256})
    record("T01", "Immutable workbook hash", "PASS" if hashes_ok else "FAIL",
           "Source and output workbook bytes match the approved SHA-256. " + zip_note,
           {"expected": EXPECTED_SHA256, "source": source_hash, "output": output_hash,
            "archive": zip_hash, "archiveStatus": "PASS" if zip_hash == EXPECTED_SHA256 else "NOT VERIFIED"})

    workbook_evidence: dict[str, Any] = {}
    try:
        values = load_workbook(output_book, data_only=True, read_only=False)
        formulas = load_workbook(output_book, data_only=False, read_only=False)
        required_sheets = {"Dashboard", "Historical_Data", "Assumptions", "Forecast_Model", "Validation", "Sources"}
        sheets_ok = required_sheets.issubset(set(values.sheetnames))
        historical = values["Historical_Data"]
        years = [historical.cell(4, col).value for col in range(3, 11)]
        hist_rows = []
        for row in list(range(5, 13)) + list(range(16, 19)):
            metric = historical.cell(row, 2).value
            unit = historical.cell(row, 11).value
            for col, year in zip(range(3, 11), years):
                hist_rows.append((metric, year, historical.cell(row, col).value, unit))
        hist_keys = [(row[0], row[1]) for row in hist_rows]
        hist_ok = (years == HISTORICAL_YEARS and [historical.cell(row, 2).value for row in list(range(5, 13)) + list(range(16, 19))] == HISTORICAL_METRICS
                   and len(hist_rows) == 88 and len(set(hist_keys)) == 88 and all(excel_numeric(row[2]) for row in hist_rows))

        assumptions = values["Assumptions"]
        assumption_rows = []
        assumption_names = []
        for row in range(10, 20):
            name = assumptions.cell(row, 2).value
            assumption_names.append(name)
            unit = assumptions.cell(row, 6).value
            for col, scenario in zip(range(3, 6), SCENARIOS):
                assumption_rows.append((name, scenario, assumptions.cell(row, col).value, unit))
        assumption_keys = [(row[0], row[1]) for row in assumption_rows]
        assumption_ok = (assumption_names == ASSUMPTION_KEYS and len(assumption_rows) == 30
                         and len(set(assumption_keys)) == 30 and all(excel_numeric(row[2]) for row in assumption_rows)
                         and all((row[3] == "Cr") if row[0] == "Shares Outstanding (Cr)" else (row[3] == "%") for row in assumption_rows))
        imported_formula_refs = []
        for sheet_name, ranges in {"Historical_Data": [(4, 5, 11, 18)], "Assumptions": [(2, 9, 7, 19)]}.items():
            sheet = formulas[sheet_name]
            for min_col, min_row, max_col, max_row in ranges:
                for row in sheet.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
                    for cell in row:
                        if isinstance(cell.value, str) and cell.value.startswith("=") and "Dashboard!" in cell.value:
                            imported_formula_refs.append(f"{sheet_name}!{cell.coordinate}")
        dashboard_error = values["Dashboard"]["B1"].value
        workbook_evidence = {
            "sheets": values.sheetnames, "historicalRows": len(hist_rows), "historicalUniqueKeys": len(set(hist_keys)),
            "assumptionRows": len(assumption_rows), "assumptionUniqueKeys": len(set(assumption_keys)),
            "dashboardB1CachedValue": dashboard_error, "dashboardDependenciesInImportedRanges": imported_formula_refs,
        }
        t02_ok = sheets_ok and hist_ok and assumption_ok and dashboard_error == "#VALUE!" and not imported_formula_refs
        record("T02", "Workbook grain, values, and dependency scope", "PASS" if t02_ok else "FAIL",
               "Workbook yields 88 numeric historical keys and the exact 30-row primary assumption set. Dashboard!B1 contains a cached #VALUE!, but imported historical and primary-assumption ranges do not reference it.", workbook_evidence)
    except Exception as exc:  # pragma: no cover - failure reporting path
        record("T02", "Workbook grain, values, and dependency scope", "FAIL", f"Workbook inspection failed: {exc}")
        values = None

    forecast_tmdl = read_text(project / "TCS_Financial_Dashboard.SemanticModel" / "definition" / "tables" / "Forecast Model.tmdl")
    fy26_contract = all(token in forecast_tmdl for token in ["267021", "66838", "52820", "145.99", "361.81"])
    fy25_contract = False
    if values:
        historical = values["Historical_Data"]
        fy25_contract = historical["J5"].value == 255324 and historical["J9"].value == 48797 and abs(historical["J10"].value - 134.2) < 0.01
    record("T03", "Headline source reconciliation", "PASS" if fy26_contract and fy25_contract else "FAIL",
           "FY2026 model fields match the documented adjusted-performance contract; FY2025 workbook headlines match the annual-report totals. Reported total profit, attributable profit, adjusted PAT, and proxy EBITDA remain distinct definitions. Earlier years were not independently re-performed in this static run.",
           {"FY2026": {"revenue": 267021, "EBIT": 66838, "adjustedPAT": 52820, "adjustedEPSBridge": 145.99, "sharesCr": 361.81,
                       "source": "https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2025-26/ar/annual-report-2025-2026.pdf",
                       "definitionNote": "Adjusted performance/model basis; reported profit and attributable profit are different measures."},
            "FY2025": {"revenue": 255324, "profitForYear": 48797, "profitAttributable": 48553, "dilutedEPS": 134.19,
                       "workbookRoundedEPS": 134.2,
                       "source": "https://www.tcs.com/content/dam/tcs/investor-relations/financial-statements/2024-25/ar/annual-report-2024-2025.pdf"},
            "scope": "FY2018-FY2024 values are structurally validated against the supplied workbook, not independently sourced in this run."})

    json_paths = sorted(project.rglob("*.json"))
    parsed_json: dict[Path, Any] = {}
    json_errors = []
    for path in json_paths:
        try:
            parsed_json[path] = json.loads(read_text(path))
        except Exception as exc:
            json_errors.append(f"{path.relative_to(project)}: {exc}")
    ref_errors = []
    try:
        pbip = json.loads(read_text(project / "TCS_Financial_Dashboard.pbip"))
        for artifact in pbip["artifacts"]:
            report_ref = project / artifact["report"]["path"]
            if not report_ref.is_dir():
                ref_errors.append(str(report_ref))
        pbir = json.loads(read_text(project / "TCS_Financial_Dashboard.Report" / "definition.pbir"))
        model_ref = (project / "TCS_Financial_Dashboard.Report" / pbir["datasetReference"]["byPath"]["path"]).resolve()
        if not model_ref.is_dir():
            ref_errors.append(str(model_ref))
        pages = json.loads(read_text(project / "TCS_Financial_Dashboard.Report" / "definition" / "pages" / "pages.json"))
        for page in pages["pageOrder"]:
            if not (project / "TCS_Financial_Dashboard.Report" / "definition" / "pages" / page / "page.json").exists():
                ref_errors.append(page)
    except Exception as exc:
        ref_errors.append(str(exc))
    record("T04", "JSON parse and project references", "PASS" if not json_errors and not ref_errors else "FAIL",
           "All local JSON and PBIP/PBIR/page references parse and resolve. Remote official JSON Schema validation was not performed offline.",
           {"jsonFiles": len(json_paths), "jsonErrors": json_errors, "referenceErrors": ref_errors,
            "officialSchemaValidation": "NOT VERIFIED (remote schemas not cached)"})

    model_definition = project / "TCS_Financial_Dashboard.SemanticModel" / "definition"
    declarations = parse_tmdl_declarations(model_definition)
    visual_refs: list[tuple[str, str, str]] = []
    for path, data in parsed_json.items():
        if path.name == "visual.json":
            collect_visual_refs(data, visual_refs)
    unresolved = []
    for entity, prop, kind in sorted(set(visual_refs)):
        bucket = "columns" if kind == "column" else "measures"
        if entity not in declarations or prop not in declarations[entity][bucket]:
            unresolved.append({"table": entity, "property": prop, "kind": kind})
    driver_text = read_text(model_definition / "tables" / "Forecast Driver.tmdl")
    driver_keys = re.findall(r'\{"([A-Z0-9_]+)",\s*"[^\"]+",\s*"[^\"]+",\s*"[^\"]+",\s*\d+\}', driver_text)
    t05_ok = len(declarations) == 7 and not unresolved and len(driver_keys) == 8 and "Forecast Driver Value" in declarations.get("Forecast Driver", {}).get("measures", set()) and "Forecast Driver Display" in declarations.get("Forecast Driver", {}).get("measures", set())
    record("T05", "TMDL declarations and PBIR field bindings", "PASS" if t05_ok else "FAIL",
           "Seven model tables are declared; all statically discoverable PBIR column/measure references resolve; the disconnected Forecast Driver presentation table exposes eight stable keys plus numeric and display measures.",
           {"tables": sorted(declarations), "visualFieldReferences": len(set(visual_refs)), "unresolved": unresolved, "forecastDriverKeys": driver_keys})

    expressions = read_text(model_definition / "expressions.tmdl")
    parameter_matches = re.findall(r"^expression\s+WorkbookPath\s*=\s*\"([^\"]+)\"", expressions, flags=re.MULTILINE)
    parameter_path = Path(parameter_matches[0]) if len(parameter_matches) == 1 else None
    hist_m = read_text(project / "Queries" / "Historical_Financials.m")
    assump_m = read_text(project / "Queries" / "Scenario_Assumptions.m")
    hist_tmdl = read_text(model_definition / "tables" / "Historical Financials.tmdl")
    assump_tmdl = read_text(model_definition / "tables" / "Scenario Assumptions.tmdl")
    guard_tokens = ["Error.Record", "MissingHeaders", "Duplicate", "MissingKeys", "InvalidRequiredValue"]
    hist_tokens = guard_tokens + ["ExpectedRowCount = 88", "File.Contents(WorkbookPath)"]
    assumption_tokens = guard_tokens + ["ExpectedRowCount = 30", "Table.FirstN", "File.Contents(WorkbookPath)"]
    parity = normalized_m(hist_m) in normalized_m(hist_tmdl) and normalized_m(assump_m) in normalized_m(assump_tmdl)
    t06_ok = (len(parameter_matches) == 1 and parameter_path is not None and parameter_path.exists()
              and "C:\\Path\\To" not in expressions and all(token in hist_m and token in hist_tmdl for token in hist_tokens)
              and all(token in assump_m and token in assump_tmdl for token in assumption_tokens) and parity)
    record("T06", "WorkbookPath and guarded M-query parity", "PASS" if t06_ok else "FAIL",
           "One required editable WorkbookPath expression points to the packaged workbook. Both deployed partitions contain consumed fail-fast Error.Record guards and match their standalone M counterparts after comment/whitespace normalization.",
           {"parameterDefinitions": len(parameter_matches), "parameterPath": str(parameter_path) if parameter_path else None,
            "parameterPathExists": bool(parameter_path and parameter_path.exists()), "standalonePartitionParity": parity})

    row_pattern = re.compile(r'\{"(Actual|Base Case|Bull Case|Bear Case)",\s*"(FY\d{4})",\s*(\d+),\s*([^}]+)\}')
    forecast_rows = []
    for scenario, year, year_sort, rest in row_pattern.findall(forecast_tmdl):
        values_raw = [part.strip() for part in rest.split(",")]
        if len(values_raw) == 8:
            parsed = [None if part == "BLANK()" else float(part) for part in values_raw]
            forecast_rows.append({"scenario": scenario, "year": year, "yearSort": int(year_sort),
                                  "revenue": parsed[0], "ebit": parsed[1], "ebitda": parsed[2], "pat": parsed[3],
                                  "cfo": parsed[4], "fcf": parsed[5], "eps": parsed[6], "shares": parsed[7]})
    keys = [(row["scenario"], row["year"]) for row in forecast_rows]
    expected_forecast_keys = {(scenario, year) for scenario in SCENARIOS for year in FORECAST_YEARS}
    t07_ok = (len(forecast_rows) == 7 and len(set(keys)) == 7 and keys.count(("Actual", "FY2026")) == 1
              and {(s, y) for s, y in keys if s != "Actual"} == expected_forecast_keys)
    record("T07", "Forecast-table grain", "PASS" if t07_ok else "FAIL",
           "Forecast Model contains one Actual FY2026 row and one row for each Base/Bull/Bear × FY2027/FY2028 key.",
           {"rows": len(forecast_rows), "uniqueKeys": len(set(keys)), "keys": keys})

    arithmetic = []
    arithmetic_ok = True
    actual = next((row for row in forecast_rows if row["scenario"] == "Actual"), None)
    by_key = {(row["scenario"], row["year"]): row for row in forecast_rows}
    if actual:
        for scenario in SCENARIOS:
            for year in FORECAST_YEARS:
                row = by_key[(scenario, year)]
                prior = actual if year == "FY2027" else by_key[(scenario, "FY2027")]
                eps_bridge = row["pat"] / row["shares"] if row["shares"] else None
                eps_delta = abs(eps_bridge - row["eps"]) if eps_bridge is not None else None
                item = {
                    "scenario": scenario, "year": year,
                    "revenueYoY": row["revenue"] / prior["revenue"] - 1,
                    "cumulativeRevenueVsFY2026": row["revenue"] / actual["revenue"] - 1,
                    "ebitMargin": row["ebit"] / row["revenue"],
                    "daToRevenue": (row["ebitda"] - row["ebit"]) / row["revenue"],
                    "adjustedPATMargin": row["pat"] / row["revenue"],
                    "cfoToAdjustedPAT": row["cfo"] / row["pat"],
                    "cfoLessFcfToRevenue": (row["cfo"] - row["fcf"]) / row["revenue"],
                    "epsBridge": eps_bridge, "storedEPS": row["eps"], "absoluteEPSDifference": eps_delta,
                }
                arithmetic.append(item)
                arithmetic_ok = arithmetic_ok and eps_delta is not None and eps_delta <= 0.1
    else:
        arithmetic_ok = False
    record("T08", "Reference forecast arithmetic", "PASS" if arithmetic_ok else "FAIL",
           "Independent Python arithmetic covers all six planning combinations. EPS bridges agree within ±₹0.10; monetary fields are preserved to the supplied ₹1 Cr precision. This is a formula mirror, not DAX-engine evidence.",
           {"tolerance": {"monetaryCrore": 1, "epsRupee": 0.1}, "combinations": arithmetic})

    historical_tmdl = hist_tmdl
    timeline_tokens = [
        "measure 'Actual Revenue'", "measure 'Scenario Forecast Revenue'",
        'TimelineYear IN {"FY2018", "FY2019", "FY2020", "FY2021", "FY2022", "FY2023", "FY2024", "FY2025"}',
        'TimelineYear = "FY2026", [FY26 Actual Revenue]', 'TimelineYear IN {"FY2027", "FY2028"}',
        "ISBLANK(TimelineYear), BLANK()", "[Forecast Prior-Year Revenue]",
    ]
    t09_ok = all(token in historical_tmdl for token in timeline_tokens) and "Fiscal Year Sort" in read_text(model_definition / "tables" / "Forecast Timeline.tmdl")
    t09_ok = t09_ok and runtime_ok
    record("T09", "Timeline and measure logic contract", "PASS" if t09_ok else "FAIL",
           "Static DAX inspection and a live local Analysis Services query establish the intended year sets, all six scenario/year states, imported-table counts, and the FY2026 bridge invariant. This does not prove visual rendering or UI interactions.",
           {"actualSeriesContract": HISTORICAL_YEARS + ["FY2026"], "scenarioSeriesContract": ["FY2026", "FY2027", "FY2028"],
             "daxRuntime": "PASS" if runtime_ok else "FAIL", "runtimeErrors": runtime_errors,
             "refreshAttempt": runtime.get("refreshAttempt"), "tableCounts": runtime_counts,
             "scenarioYearStates": len(runtime_scenarios), "fy2026Bridge": runtime_bridge_ok})

    pages_root = project / "TCS_Financial_Dashboard.Report" / "definition" / "pages"
    geometry = {}
    geometry_ok = True
    visual_data: dict[str, dict[str, dict[str, Any]]] = {}
    for page_name in REPORT_PAGES:
        page = json.loads(read_text(pages_root / page_name / "page.json"))
        visuals = {}
        bounds_errors = []
        for visual_path in sorted((pages_root / page_name / "visuals").glob("*/visual.json")):
            data = json.loads(read_text(visual_path))
            pos = data["position"]
            visuals[data["name"]] = data
            if pos["x"] < 0 or pos["y"] < 0 or pos["width"] <= 0 or pos["height"] <= 0 or pos["x"] + pos["width"] > page["width"] or pos["y"] + pos["height"] > page["height"]:
                bounds_errors.append(data["name"])
        overlaps = []
        for left, right in itertools.combinations(visuals.values(), 2):
            a, b = left["position"], right["position"]
            if max(a["x"], b["x"]) < min(a["x"] + a["width"], b["x"] + b["width"]) and max(a["y"], b["y"]) < min(a["y"] + a["height"], b["y"] + b["height"]):
                overlaps.append([left["name"], right["name"]])
        tabs = [visual["position"].get("tabOrder") for visual in visuals.values()]
        geometry[page_name] = {"canvas": [page["width"], page["height"]], "visuals": len(visuals), "outOfBounds": bounds_errors, "overlaps": overlaps, "tabOrders": sorted(tabs)}
        geometry_ok = geometry_ok and page["width"] == 1280 and page["height"] == 720 and not bounds_errors and not overlaps
        visual_data[page_name] = visuals
    record("T10", "Page geometry and overlap", "PASS" if geometry_ok else "FAIL",
           "All four pages are 1280×720; every visual has positive in-canvas geometry; strict pairwise rectangle inspection finds no intersections.", geometry)

    detail_metric_text = read_text(pages_root / "detail" / "visuals" / "detail_metric_values" / "visual.json")
    detail_table_text = read_text(pages_root / "detail" / "visuals" / "detail_detail_table" / "visual.json")
    trend_ids = set(visual_data["trend"])
    monetary_metrics = ["Revenue", "EBITDA", "EBIT", "Other Income (Net)", "Net Profit", "Depreciation", "Capex", "Free Cash Flow"]
    excluded_mixed = ["EPS - Diluted (INR)", "Shares Outstanding", "Employees"]
    t11_ok = all(metric in detail_metric_text for metric in monetary_metrics) and all(metric not in detail_metric_text for metric in excluded_mixed) and "Fiscal Year" in detail_table_text and "Unit" in detail_table_text and not any("year" in visual_id.lower() for visual_id in trend_ids)
    record("T11", "Units, labels, and detail/trend scope", "PASS" if t11_ok else "FAIL",
           "The detail bar is filtered to eight ₹ Cr metrics, excluding EPS/shares/employees; the detail table carries year and unit fields; Trend has no year slicer. Grand-total rendering and label clipping require Desktop inspection.",
           {"detailMonetaryMetrics": monetary_metrics, "excludedMixedUnitMetrics": excluded_mixed, "trendVisualIds": sorted(trend_ids)})

    interaction_errors = []
    for page_name, visuals in visual_data.items():
        page = json.loads(read_text(pages_root / page_name / "page.json"))
        ids = set(visuals)
        tabs = [visual["position"].get("tabOrder") for visual in visuals.values()]
        if None in tabs or len(tabs) != len(set(tabs)):
            interaction_errors.append(f"{page_name}: tabOrder is missing or duplicated")
        for interaction in page.get("visualInteractions", []):
            if interaction.get("source") not in ids or interaction.get("target") not in ids:
                interaction_errors.append(f"{page_name}: invalid interaction endpoint {interaction}")
    detail_page = json.loads(read_text(pages_root / "detail" / "page.json"))
    hist_targets = {(item["target"], item["type"]) for item in detail_page["visualInteractions"] if item["source"] == "detail_historical_year"}
    expected_data_targets = {("detail_metric_values", "DataFilter"), ("detail_detail_table", "DataFilter")}
    actual_data_targets = {item for item in hist_targets if item[1] != "NoFilter"}
    if actual_data_targets != expected_data_targets:
        interaction_errors.append(f"detail: historical year data targets {sorted(actual_data_targets)}")
    scenario_page_text = read_text(pages_root / "scenario" / "page.json")
    comparison_text = read_text(pages_root / "scenario" / "visuals" / "scenario_comparison" / "visual.json")
    selector_defaults_ok = all(
        "'Base Case'" in read_text(pages_root / page / "visuals" / f"{page}_scenario" / "visual.json")
        and "'FY2028'" in read_text(pages_root / page / "visuals" / f"{page}_year" / "visual.json")
        for page in SELECTOR_PAGES
    )
    comparison_ok = all(f"'{scenario}'" in comparison_text for scenario in SCENARIOS) and "'Actual'" not in comparison_text and '"source": "scenario_comparison"' in scenario_page_text and '"type": "NoFilter"' in scenario_page_text
    t12_ok = not interaction_errors and selector_defaults_ok and comparison_ok
    record("T12", "Controls, tab order, and interaction matrix", "PASS" if t12_ok else "FAIL",
           "All interaction endpoints resolve, page tab orders are unique, selectors default to Base Case/FY2028, comparison excludes Actual and preserves all three cases, and Detail Historical Year filters exactly its two intended targets. Cross-page slicer persistence is deferred to Desktop.",
           {"errors": interaction_errors, "selectorDefaults": selector_defaults_ok, "comparisonContract": comparison_ok,
            "crossPageSync": "NOT VERIFIED / DEFERRED TO DESKTOP"})

    contrast = {
        "navyOnSlate": round(contrast_ratio("#0F172A", "#F1F5F9"), 2),
        "navyOnWhite": round(contrast_ratio("#0F172A", "#FFFFFF"), 2),
        "whiteOnNavy": round(contrast_ratio("#FFFFFF", "#0F172A"), 2),
    }
    alt_missing = []
    for page_name, visuals in visual_data.items():
        for visual_id, data in visuals.items():
            if not literal_value(data.get("visual", {}), "altText"):
                alt_missing.append(f"{page_name}/{visual_id}")
    t13_ok = min(contrast.values()) >= 4.5 and not alt_missing
    record("T13", "Static accessibility and contrast", "PASS" if t13_ok else "FAIL",
           "Primary text/background pairs exceed WCAG 4.5:1 and every visual declares alt text. Color-dependent meaning is supplemented by metric/scenario labels. Font clipping and keyboard behavior remain Desktop checks.",
           {"contrastRatios": contrast, "missingAltText": alt_missing, "manualClipping": "NOT VERIFIED"})

    required_paths = [
        "TCS_Financial_Dashboard.pbip", "Data/TCS_Historical_Financials.xlsx",
        "TCS_Financial_Dashboard.Report/definition.pbir", "TCS_Financial_Dashboard.SemanticModel/definition.pbism",
        "Queries/Historical_Financials.m", "Queries/Scenario_Assumptions.m", "Measures/Dashboard_Measures.dax",
        "README.md", "BUILD_GUIDE.md", "DATA_DICTIONARY.md", "VALIDATION_REPORT.md", "DESKTOP_CHECKLIST.md",
        "tools/validate_project.py",
        "previews/executive-layout.png", "previews/trend-layout.png", "previews/scenario-layout.png", "previews/detail-layout.png",
        "runtime-validation.json", "tools/run_runtime_probe.ps1", "tools/runtime_probe/runtime_probe.csproj", "tools/runtime_probe/Program.cs",
        "docs/tmdl-parser-evidence.json",
    ]
    missing = [path for path in required_paths if not (project / path).exists()]
    files = [path for path in project.rglob("*") if path.is_file()]
    absolute_lengths = {str(path): len(str(path.resolve())) for path in files}
    relative_lengths = {path.relative_to(project).as_posix(): len(path.relative_to(project).as_posix()) for path in files}
    max_abs_path, max_abs = max(absolute_lengths.items(), key=lambda item: item[1]) if absolute_lengths else ("", 0)
    max_rel_path, max_rel = max(relative_lengths.items(), key=lambda item: item[1]) if relative_lengths else ("", 0)
    secrets = [str(path.relative_to(project)) for path in files if path.name.lower() in {".env", "credentials.json", "secrets.json"}]
    generated_build_artifacts = [str(path.relative_to(project)) for path in files if any(part in {"__pycache__", "bin", "obj"} for part in path.relative_to(project).parts)]
    t14_ok = not missing and not secrets and max_abs < 260
    record("T14", "Package manifest, path lengths, and ZIP readiness", "PASS" if t14_ok else "FAIL",
           "Required editable project, source, query, measure, evidence, validator, and preview files are present; no cache/credential filenames were found; delivered paths are below 260 characters. ZIP integrity is checked in G007 when the archive exists.",
            {"fileCount": len(files), "missing": missing, "credentialArtifactsFound": secrets,
             "generatedBuildArtifactsToExcludeFromZip": generated_build_artifacts,
            "maxAbsolutePathLength": max_abs, "maxAbsolutePath": max_abs_path,
            "maxRelativeArchivePathLength": max_rel, "maxRelativeArchivePath": max_rel_path,
            "zip": str(zip_path), "zipStatus": "PASS" if zip_path.exists() and zip_hash == EXPECTED_SHA256 else "NOT VERIFIED / PENDING G007"})

    tmdl_evidence_path = project / "docs" / "tmdl-parser-evidence.json"
    try:
        tmdl_evidence = json.loads(read_text(tmdl_evidence_path))
    except Exception as exc:
        tmdl_evidence = {"status": "FAIL", "diagnostics": str(exc)}
    t15_ok = runtime_ok and tmdl_evidence.get("status") == "PASS" and "TMDL_OK" in tmdl_evidence.get("diagnostics", "")
    record("T15", "Official TMDL parse, model load, and live engine execution", "PASS" if t15_ok else "FAIL",
           "The official TmdlSerializer parsed the semantic-model folder. Power BI Desktop then loaded the edited PBIP model and its local Analysis Services engine accepted import refresh and DAX queries. Rendering and UI behavior remain separate checks.",
           {"parser": tmdl_evidence, "runtimeClient": runtime.get("client"),
            "catalog": runtime.get("catalog"), "runtimeGeneratedAt": runtime.get("generatedAt")})

    summary = Counter(check["status"] for check in checks)
    result = {
        "schemaVersion": "1.0",
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "project": str(project),
        "source": str(source),
        "evidenceBoundary": {
            "proven": "Static file/workbook/model-declaration/PBIR/arithmetic/layout/interaction/package checks, official TMDL deserialization, plus live Power BI Analysis Services import refresh and DAX queries",
            "notVerified": ["Power BI visual rendering", "UI interaction behavior", "cross-page slicer sync", "save/reopen persistence", "remote JSON Schema validation"],
        },
        "summary": {"PASS": summary["PASS"], "FAIL": summary["FAIL"], "NOT_VERIFIED": summary["NOT VERIFIED"]},
        "checks": checks,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], ensure_ascii=False))
    for check in checks:
        print(f"{check['id']} {check['status']}: {check['title']}")
    return 1 if summary["FAIL"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
